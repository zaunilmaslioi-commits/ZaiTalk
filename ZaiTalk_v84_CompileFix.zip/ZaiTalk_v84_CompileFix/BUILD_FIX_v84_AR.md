# ZaiTalk v84 - Build Fix

تم إصلاح أخطاء التجميع في النسخة السابقة:

- إضافة `SupabaseConfig.getUrl()` و `SupabaseConfig.getKey()` المطلوبة من `NotificationRealtime`.
- إضافة دوال التوافق `insert(table, JSONObject)` و `patch(table, query, JSONObject)` و `delete(table, query)` المطلوبة من `MainActivity`.
- تصحيح `SessionStore.clear()` لمسح جلسة الذاكرة عند تسجيل الخروج.

هذه النسخة لا تحتوي على `local.properties` أو مفاتيح Supabase سرية.

## اسم ملف المشروع
`ZaiTalk_v84_CompileFix.zip`
