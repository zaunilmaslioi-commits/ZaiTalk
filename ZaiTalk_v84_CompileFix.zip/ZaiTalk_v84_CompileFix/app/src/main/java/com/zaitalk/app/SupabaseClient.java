package com.zaitalk.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import okhttp3.*;

public class SupabaseClient {
  private final String base=SupabaseConfig.URL.replaceAll("/+$","");
  private final String key=SupabaseConfig.KEY;
  private String token="";

  public void token(String t){ token=t==null?"":t; }

  private String request(String method,String path,String body)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(base+path).openConnection();
    c.setRequestMethod(method);
    c.setConnectTimeout(15000);
    c.setReadTimeout(20000);
    c.setRequestProperty("apikey",key);
    c.setRequestProperty("Authorization","Bearer "+(token.isEmpty()?key:token));
    c.setRequestProperty("Accept","application/json");
    c.setRequestProperty("Content-Type","application/json");
    if(body!=null){
      c.setDoOutput(true);
      byte[] b=body.getBytes(StandardCharsets.UTF_8);
      try(OutputStream o=c.getOutputStream()){o.write(b);}
    }
    int code=c.getResponseCode();
    InputStream s=code<400?c.getInputStream():c.getErrorStream();
    StringBuilder out=new StringBuilder();
    if(s!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(s,StandardCharsets.UTF_8))){
      String line; while((line=r.readLine())!=null) out.append(line);
    }
    c.disconnect();
    if(code<200||code>=300) throw new Exception("HTTP "+code+": "+out);
    return out.toString();
  }

  private static SupabaseClient current(){
    SupabaseClient c=new SupabaseClient();
    c.token(SessionStore.getToken());
    return c;
  }

  // Compatibility API used by earlier ZaiTalk modules.
  public static String select(String path)throws Exception{
    return current().request("GET","/rest/v1/"+path,null);
  }
  public static String insert(String table,String body)throws Exception{
    return current().request("POST","/rest/v1/"+table,body);
  }
  public static void patch(String path,String body)throws Exception{
    current().request("PATCH","/rest/v1/"+path,body);
  }
  public static void delete(String path)throws Exception{
    current().request("DELETE","/rest/v1/"+path,null);
  }

  // Instance compatibility overloads used by MainActivity.
  public void insert(String table,JSONObject body)throws Exception{
    request("POST","/rest/v1/"+table,body.toString());
  }
  public void patch(String table,String query,JSONObject body)throws Exception{
    request("PATCH","/rest/v1/"+table+"?"+query,body.toString());
  }
  public void delete(String table,String query)throws Exception{
    request("DELETE","/rest/v1/"+table+"?"+query,null);
  }

  // Auth API.
  public JSONObject auth(String email,String pass)throws Exception{
    JSONObject b=new JSONObject(); b.put("email",email); b.put("password",pass);
    return new JSONObject(request("POST","/auth/v1/token?grant_type=password",b.toString()));
  }
  public JSONObject signup(String email,String pass)throws Exception{
    JSONObject b=new JSONObject(); b.put("email",email); b.put("password",pass);
    return new JSONObject(request("POST","/auth/v1/signup",b.toString()));
  }
  public void resetPassword(String email)throws Exception{
    JSONObject b=new JSONObject(); b.put("email",email);
    request("POST","/auth/v1/recover",b.toString());
  }
  public void updatePassword(String password)throws Exception{
    JSONObject b=new JSONObject(); b.put("password",password);
    request("PUT","/auth/v1/user",b.toString());
  }

  // Authenticated instance API.
  // Instance compatibility API used by MainActivity and managers.
  public JSONArray select(String table,String q)throws Exception{
    return new JSONArray(request("GET","/rest/v1/"+table+"?"+q,null));
  }

  public JSONArray selectAuth(String table,String q)throws Exception{
    return new JSONArray(request("GET","/rest/v1/"+table+"?"+q,null));
  }
  public JSONArray insertAuth(String table,JSONObject o)throws Exception{
    return new JSONArray(request("POST","/rest/v1/"+table,o.toString()));
  }
  public void deleteAuth(String table,String q)throws Exception{
    request("DELETE","/rest/v1/"+table+"?"+q,null);
  }
  public void patchAuth(String table,String q,JSONObject o)throws Exception{
    request("PATCH","/rest/v1/"+table+"?"+q,o.toString());
  }

  public static String setPassword(String accessToken,String password)throws Exception{
    SupabaseClient c=new SupabaseClient();
    c.token(accessToken);
    JSONObject b=new JSONObject(); b.put("password",password);
    return c.request("PUT","/auth/v1/user",b.toString());
  }

  public static void uploadStorage(String bucket,String path,byte[] data,String contentType)throws Exception{
    OkHttpClient c=new OkHttpClient();
    RequestBody body=RequestBody.create(data,MediaType.parse(contentType));
    Request r=new Request.Builder()
      .url(SupabaseConfig.URL+"/storage/v1/object/"+bucket+"/"+path)
      .addHeader("apikey",SupabaseConfig.KEY)
      .addHeader("Authorization","Bearer "+(SessionStore.getToken().isEmpty()?SupabaseConfig.KEY:SessionStore.getToken()))
      .addHeader("Content-Type",contentType)
      .addHeader("x-upsert","true")
      .post(body).build();
    Response resp=c.newCall(r).execute();
    if(!resp.isSuccessful()) throw new Exception("storage upload failed: "+resp.code());
    resp.close();
  }

  public static String storagePublicUrl(String bucket,String path){
    return SupabaseConfig.URL+"/storage/v1/object/public/"+bucket+"/"+path;
  }
}