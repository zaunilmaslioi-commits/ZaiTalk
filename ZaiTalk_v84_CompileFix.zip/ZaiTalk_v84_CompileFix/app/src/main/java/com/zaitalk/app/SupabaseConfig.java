package com.zaitalk.app;
public final class SupabaseConfig{
 public static final String URL=BuildConfig.SUPABASE_URL, KEY=BuildConfig.SUPABASE_KEY;
 public static boolean ok(){return URL!=null&&!URL.isEmpty()&&KEY!=null&&!KEY.isEmpty()&&!URL.contains("YOUR_");}
 public static String getUrl(){return URL;}
 public static String getKey(){return KEY;}
}
