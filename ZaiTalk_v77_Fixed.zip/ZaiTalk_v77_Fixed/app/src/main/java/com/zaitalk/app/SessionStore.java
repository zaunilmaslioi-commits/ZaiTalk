package com.zaitalk.app;
import android.content.*;
public class SessionStore{
 private final SharedPreferences p;
 public SessionStore(Context c){p=c.getSharedPreferences("zaitalk",0);}
 public void save(String t,String u){p.edit().putString("t",t).putString("u",u).apply();}
 public String token(){return p.getString("t","");} public String uid(){return p.getString("u","");}
 public void clear(){p.edit().clear().apply();}

  private static String runtimeToken="";
  public static String getToken(){ return runtimeToken; }
}
