package com.zaitalk.app;

import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class HomeFeedManager {
  private final MainActivity a;
  public HomeFeedManager(MainActivity activity){a=activity;}

  public void load(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?select=*&order=created_at.desc&limit=30");
        a.runOnUiThread(()->render(box,raw));
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر تحميل المنشورات",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }

  private void render(LinearLayout box,String raw){
    box.removeAllViews();
    try{
      JSONArray posts=new JSONArray(raw);
      if(posts.length()==0){
        TextView empty=new TextView(a);
        empty.setText("لا توجد منشورات بعد");
        empty.setTextColor(Color.WHITE);
        empty.setTextSize(17);
        box.addView(empty);
        return;
      }

      for(int i=0;i<posts.length();i++){
        JSONObject p=posts.getJSONObject(i);
        addPost(box,p);
      }
    }catch(Exception ignored){}
  }

  private void addPost(LinearLayout box,JSONObject p){
    String id=p.optString("id");
    String text=p.optString("content",p.optString("caption",""));
    String media=p.optString("media_url","");
    String owner=p.optString("user_id","");

    LinearLayout card=new LinearLayout(a);
    card.setOrientation(LinearLayout.VERTICAL);
    card.setPadding(16,16,16,16);
    card.setBackgroundColor(Color.rgb(27,27,32));

    TextView user=new TextView(a);
    user.setText("👤 "+owner);
    user.setTextColor(Color.WHITE);
    user.setTextSize(15);
    card.addView(user);

    if(!media.isEmpty()){
      ImageView image=new ImageView(a);
      image.setAdjustViewBounds(true);
      image.setScaleType(ImageView.ScaleType.CENTER_CROP);
      // URL loading can be connected to Glide/Picasso in the next UI pass.
      image.setContentDescription("صورة المنشور");
      card.addView(image);
    }

    if(!text.isEmpty()){
      TextView body=new TextView(a);
      body.setText(text);
      body.setTextColor(Color.WHITE);
      body.setTextSize(17);
      body.setPadding(0,14,0,10);
      card.addView(body);
    }

    LinearLayout actions=new LinearLayout(a);
    actions.setOrientation(LinearLayout.HORIZONTAL);

    Button like=new Button(a);
    like.setText("❤️ إعجاب");
    Button comment=new Button(a);
    comment.setText("💬 تعليق");
    Button save=new Button(a);
    save.setText("🔖 حفظ");
    Button share=new Button(a);
    share.setText("↗ مشاركة");

    actions.addView(like,new LinearLayout.LayoutParams(0,52,1));
    actions.addView(comment,new LinearLayout.LayoutParams(0,52,1));
    actions.addView(save,new LinearLayout.LayoutParams(0,52,1));
    actions.addView(share,new LinearLayout.LayoutParams(0,52,1));
    card.addView(actions);

    like.setOnClickListener(v->likePost(id,owner));
    comment.setOnClickListener(v->showCommentBox(id,owner));
    save.setOnClickListener(v->savePost(id));
    share.setOnClickListener(v->sharePost(text,media));

    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(
      -1,LinearLayout.LayoutParams.WRAP_CONTENT);
    cp.setMargins(0,0,0,18);
    box.addView(card,cp);
  }

  private void likePost(String postId,String ownerId){
    new Thread(()->{
      try{
        JSONObject x=new JSONObject();
        x.put("user_id",SessionStore.getUserId());
        x.put("post_id",postId);
        SupabaseClient.insert("likes",x.toString());
        SocialNotificationHelper.like(ownerId,postId);
        a.runOnUiThread(()->toast("تم الإعجاب ❤️"));
      }catch(Exception e){a.runOnUiThread(()->toast("تعذر الإعجاب")); }
    }).start();
  }

  private void savePost(String postId){
    new Thread(()->{
      try{
        JSONObject x=new JSONObject();
        x.put("user_id",SessionStore.getUserId());
        x.put("post_id",postId);
        SupabaseClient.insert("saves",x.toString());
        a.runOnUiThread(()->toast("تم حفظ المنشور 🔖"));
      }catch(Exception e){a.runOnUiThread(()->toast("تعذر الحفظ")); }
    }).start();
  }

  private void showCommentBox(String postId,String ownerId){
    final EditText input=new EditText(a);
    input.setHint("اكتب تعليقك...");
    new AlertDialog.Builder(a)
      .setTitle("تعليق")
      .setView(input)
      .setNegativeButton("إلغاء",null)
      .setPositiveButton("نشر",(d,w)->{
        String text=input.getText().toString().trim();
        if(text.isEmpty())return;
        new Thread(()->{
          try{
            JSONObject x=new JSONObject();
            x.put("user_id",SessionStore.getUserId());
            x.put("post_id",postId);
            x.put("content",text);
            SupabaseClient.insert("comments",x.toString());
            SocialNotificationHelper.comment(ownerId,postId);
            a.runOnUiThread(()->toast("تم نشر التعليق 💬"));
          }catch(Exception e){a.runOnUiThread(()->toast("تعذر نشر التعليق")); }
        }).start();
      }).show();
  }

  private void sharePost(String text,String media){
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("text/plain");
    i.putExtra(Intent.EXTRA_TEXT,
      text.isEmpty()?media:text);
    a.startActivity(Intent.createChooser(i,"مشاركة المنشور"));
  }

  private void toast(String s){
    Toast.makeText(a,s,Toast.LENGTH_SHORT).show();
  }
}