package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.viewpager2.widget.ViewPager2;
import androidx.recyclerview.widget.RecyclerView;
import android.content.*;
import android.net.Uri;
import org.json.*;
import java.util.*;

public class ReelsProActivity extends Activity {
  private ViewPager2 pager;
  private ArrayList<JSONObject> items=new ArrayList<>();
  private final ArrayList<VideoView> activeVideos=new ArrayList<>();

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    pager=new ViewPager2(this);
    pager.setOrientation(ViewPager2.ORIENTATION_VERTICAL);
    pager.setBackgroundColor(Color.BLACK);
    setContentView(pager);

    pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback(){
      @Override public void onPageSelected(int position){
        stopAllExcept(position);
        if(position>=0 && position<activeVideos.size()){
          VideoView v=activeVideos.get(position);
          if(v!=null)v.start();
        }
      }
    });
    load();
  }

  private void load(){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?media_type=eq.video&select=*&order=created_at.desc&limit=50");
        JSONArray a=new JSONArray(raw);
        for(int i=0;i<a.length();i++)items.add(a.getJSONObject(i));
        runOnUiThread(()->pager.setAdapter(new Adapter()));
      }catch(Exception ignored){}
    }).start();
  }

  private void stopAllExcept(int keep){
    for(int i=0;i<activeVideos.size();i++){
      if(i!=keep && activeVideos.get(i)!=null){
        try{activeVideos.get(i).pause();}catch(Exception ignored){}
      }
    }
  }

  private class Adapter extends RecyclerView.Adapter<Holder>{
    public int getItemCount(){return items.size();}
    public Holder onCreateViewHolder(android.view.ViewGroup p,int t){
      FrameLayout box=new FrameLayout(ReelsProActivity.this);
      box.setBackgroundColor(Color.BLACK);
      return new Holder(box);
    }

    public void onBindViewHolder(Holder h,int pos){
      JSONObject x=items.get(pos);
      h.box.removeAllViews();

      VideoView video=new VideoView(ReelsProActivity.this);
      h.box.addView(video,new FrameLayout.LayoutParams(-1,-1));
      while(activeVideos.size()<=pos)activeVideos.add(null);
      activeVideos.set(pos,video);

      String url=x.optString("media_url","");
      if(!url.isEmpty()){
        video.setVideoURI(Uri.parse(url));
        video.setOnPreparedListener(mp->{
          mp.setLooping(true);
          if(pos==pager.getCurrentItem())video.start();
        });
      }

      String postId=x.optString("id");
      String owner=x.optString("user_id");

      LinearLayout side=new LinearLayout(ReelsProActivity.this);
      side.setOrientation(LinearLayout.VERTICAL);
      side.setGravity(Gravity.CENTER);

      TextView likeCount=new TextView(ReelsProActivity.this);
      TextView commentCount=new TextView(ReelsProActivity.this);
      likeCount.setTextColor(Color.WHITE);
      commentCount.setTextColor(Color.WHITE);
      likeCount.setGravity(Gravity.CENTER);
      commentCount.setGravity(Gravity.CENTER);

      Button like=new Button(ReelsProActivity.this);
      like.setText("❤️");
      Button comment=new Button(ReelsProActivity.this);
      comment.setText("💬");
      Button follow=new Button(ReelsProActivity.this);
      follow.setText("+ متابعة");
      Button save=new Button(ReelsProActivity.this);
      save.setText("🔖");
      Button share=new Button(ReelsProActivity.this);
      share.setText("↗");

      side.addView(like);
      side.addView(likeCount);
      side.addView(comment);
      side.addView(commentCount);
      side.addView(follow);
      side.addView(save);
      side.addView(share);

      FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(
        150,-2,Gravity.RIGHT|Gravity.CENTER_VERTICAL);
      sp.setMargins(0,0,8,0);
      h.box.addView(side,sp);

      TextView caption=new TextView(ReelsProActivity.this);
      caption.setText(x.optString("content",x.optString("caption","")));
      caption.setTextColor(Color.WHITE);
      caption.setTextSize(17);
      caption.setPadding(20,20,170,40);
      FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
      h.box.addView(caption,cp);

      loadCounts(postId,likeCount,commentCount);
      loadFollow(owner,follow);

      like.setOnClickListener(v->{
        like(postId,owner);
        likeCount.setText("…");
        loadCounts(postId,likeCount,commentCount);
      });
      comment.setOnClickListener(v->comment(postId,owner,commentCount));
      follow.setOnClickListener(v->{
        new Thread(()->{
          try{
            ReelsInteractionManager.follow(owner);
            runOnUiThread(()->{
              follow.setText("✓ متابَع");
              follow.setEnabled(false);
            });
          }catch(Exception e){
            runOnUiThread(()->toast("تعذر المتابعة"));
          }
        }).start();
      });
      save.setOnClickListener(v->{
        new Thread(()->{
          try{
            ReelsInteractionManager.save(postId);
            runOnUiThread(()->toast("تم حفظ الريل 🔖"));
          }catch(Exception e){
            runOnUiThread(()->toast("تعذر الحفظ"));
          }
        }).start();
      });
      share.setOnClickListener(v->share(caption.getText().toString()));
    }

    public void onViewRecycled(Holder h){
      super.onViewRecycled(h);
      for(int i=0;i<h.box.getChildCount();i++){
        View v=h.box.getChildAt(i);
        if(v instanceof VideoView)((VideoView)v).stopPlayback();
      }
    }
  }

  private static class Holder extends RecyclerView.ViewHolder{
    FrameLayout box;
    Holder(FrameLayout v){super(v);box=v;}
  }

  private void loadCounts(String postId,TextView likes,TextView comments){
    new Thread(()->{
      try{
        int l=ReelsInteractionManager.countLikes(postId);
        int c=ReelsInteractionManager.countComments(postId);
        runOnUiThread(()->{
          likes.setText(String.valueOf(l));
          comments.setText(String.valueOf(c));
        });
      }catch(Exception ignored){}
    }).start();
  }

  private void loadFollow(String owner,Button b){
    if(owner.equals(SessionStore.getUserId())){
      b.setVisibility(View.GONE); return;
    }
    new Thread(()->{
      try{
        boolean f=ReelsInteractionManager.isFollowing(owner);
        runOnUiThread(()->{
          b.setText(f?"✓ متابَع":"+ متابعة");
          b.setEnabled(!f);
        });
      }catch(Exception ignored){}
    }).start();
  }

  private void like(String postId,String owner){
    new Thread(()->{
      try{
        JSONObject p=new JSONObject();
        p.put("user_id",SessionStore.getUserId());
        p.put("post_id",postId);
        SupabaseClient.insert("likes",p.toString());
        SocialNotificationHelper.like(owner,postId);
        runOnUiThread(()->toast("تم الإعجاب ❤️"));
      }catch(Exception e){runOnUiThread(()->toast("تعذر الإعجاب"));}
    }).start();
  }

  private void comment(String postId,String owner,TextView count){
    EditText input=new EditText(this);
    input.setHint("اكتب تعليقك...");
    new AlertDialog.Builder(this).setTitle("تعليق")
      .setView(input).setNegativeButton("إلغاء",null)
      .setPositiveButton("نشر",(d,w)->{
        String s=input.getText().toString().trim();
        if(s.isEmpty())return;
        new Thread(()->{
          try{
            JSONObject p=new JSONObject();
            p.put("user_id",SessionStore.getUserId());
            p.put("post_id",postId);
            p.put("content",s);
            SupabaseClient.insert("comments",p.toString());
            SocialNotificationHelper.comment(owner,postId);
            int c=ReelsInteractionManager.countComments(postId);
            runOnUiThread(()->{
              count.setText(String.valueOf(c));
              toast("تم نشر التعليق 💬");
            });
          }catch(Exception e){runOnUiThread(()->toast("تعذر نشر التعليق"));}
        }).start();
      }).show();
  }

  private void share(String text){
    Intent i=new Intent(Intent.ACTION_SEND);
    i.setType("text/plain");
    i.putExtra(Intent.EXTRA_TEXT,text);
    startActivity(Intent.createChooser(i,"مشاركة الريل"));
  }

  private void toast(String s){
    Toast.makeText(this,s,Toast.LENGTH_SHORT).show();
  }
}