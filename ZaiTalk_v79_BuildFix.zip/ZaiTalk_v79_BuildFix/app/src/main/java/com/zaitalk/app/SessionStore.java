package com.zaitalk.app;
import android.content.*;
public class SessionStore{
 private final SharedPreferences p;
 public SessionStore(Context c){p=c.getSharedPreferences("zaitalk",0); runtimeToken=p.getString("t",""); runtimeUserId=p.getString("u","");}
 public void save(String t,String u){runtimeToken=t==null?"":t; runtimeUserId=u==null?"":u; p.edit().putString("t",runtimeToken).putString("u",runtimeUserId).apply();}
 public String token(){return p.getString("t","");}
 public String uid(){return p.getString("u","");}
 public void clear(){runtimeToken=""; runtimeUserId=""; p.edit().clear().apply();}
 private static String runtimeToken="";
 private static String runtimeUserId="";
 public static String getToken(){ return runtimeToken; }
 public static String getUserId(){ return runtimeUserId; }
}
