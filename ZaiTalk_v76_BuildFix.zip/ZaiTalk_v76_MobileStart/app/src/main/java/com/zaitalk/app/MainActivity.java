package com.zaitalk.app;
import android.Manifest;
import android.app.*;import android.content.pm.PackageManager;
import android.content.*;import android.net.Uri;
import android.provider.MediaStore;import java.io.ByteArrayOutputStream;import java.io.InputStream;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import org.json.*;import java.util.concurrent.*;
public class MainActivity extends Activity{
 ExecutorService ex=Executors.newSingleThreadExecutor(); SessionStore s; SupabaseClient db; SupabaseStorage storage; LinearLayout root,content; boolean demo;
 int BG=Color.rgb(11,18,32),CARD=Color.rgb(20,30,48),GREEN=Color.rgb(16,185,129),WHITE=Color.WHITE,MUTED=Color.rgb(170,185,205);
 @Override public void onCreate(Bundle b){super.onCreate(b);s=new SessionStore(this);db=new SupabaseClient();storage=new SupabaseStorage();demo=!SupabaseConfig.ok();if(!s.token().isEmpty()){db.token(s.token());storage.token(s.token());app();}else login();}
 TextView t(String x,int z){TextView v=new TextView(this);v.setText(x);v.setTextColor(WHITE);v.setTextSize(z);v.setPadding(16,12,16,12);return v;}
 Button btn(String x){Button b=new Button(this);b.setText(x);b.setTextColor(WHITE);b.setTextSize(14);b.setAllCaps(false);GradientDrawable g=new GradientDrawable();g.setColor(GREEN);g.setCornerRadius(20);b.setBackground(g);return b;}
 EditText inp(String h,boolean pw){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setSingleLine();if(pw)e.setInputType(129);GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(18);e.setBackground(g);return e;}
 LinearLayout.LayoutParams lp(int a,int b,int c,int d){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(a,b,c,d);return p;}
 void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);TextView h=t(title,24);h.setTypeface(null,1);root.addView(h);ScrollView sc=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(10,5,10,90);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
 void login(){base("ZaiTalk");content.addView(t("أهلاً بك 👋",32),lp(5,35,5,5));content.addView(t(demo?"وضع تجريبي — فعّل Supabase حتى تعمل الحسابات السحابية":"سجّل الدخول إلى ZaiTalk",16),lp(5,5,5,20));
  EditText e=inp("البريد الإلكتروني",false),p=inp("كلمة المرور",true);content.addView(e,lp(5,5,5,8));content.addView(p,lp(5,5,5,12));Button l=btn("تسجيل الدخول"),n=btn("إنشاء حساب");content.addView(l,lp(5,5,5,8));content.addView(n,lp(5,5,5,8)); Button forgot=btn("نسيت كلمة المرور؟"); content.addView(forgot,lp(5,3,5,8));
  forgot.setOnClickListener(v->forgotPasswordDialog());
  l.setOnClickListener(v->{if(demo){app();return;}work(()->{try{JSONObject r=db.auth(e.getText().toString().trim(),p.getText().toString());String tok=r.optString("access_token");String uid=r.optJSONObject("user")!=null?r.getJSONObject("user").optString("id"):"";s.save(tok,uid);db.token(tok);storage.token(tok);ui(this::app);}catch(Exception x){ui(()->toast(x.getMessage()));}});});
  n.setOnClickListener(v->{if(demo){toast("أضف بيانات Supabase في local.properties");return;}work(()->{try{JSONObject r=db.signup(e.getText().toString().trim(),p.getText().toString());if(r.has("access_token")){String tok=r.optString("access_token"),uid=r.optJSONObject("user").optString("id");s.save(tok,uid);db.token(tok);storage.token(tok);ui(this::app);}else ui(this::verificationPage);}catch(Exception x){ui(()->toast(x.getMessage()));}});});
 }
 void forgotPasswordDialog(){
  EditText e=inp("البريد الإلكتروني",false);
  Button b=btn("إرسال رابط الاستعادة");
  LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(15,10,15,10);
  l.addView(e);l.addView(b,lp(0,10,0,0));
  Dialog d=new Dialog(this);d.setTitle("استعادة كلمة المرور");d.setContentView(l);
  b.setOnClickListener(v->{
    String email=e.getText().toString().trim(); if(email.isEmpty())return;
    if(demo){d.dismiss();toast("في الوضع التجريبي لا يتم إرسال بريد.");return;}
    work(()->{try{
      db.resetPassword(email);
      ui(()->{d.dismiss();toast("تم إرسال رابط استعادة كلمة المرور إلى بريدك إذا كان الحساب موجوداً.");});
    }catch(Exception x){ui(()->toast("تعذر إرسال الرابط: "+x.getMessage()));}});
  });
  d.show();
 }

 void verificationPage(){
  base("تأكيد البريد");
  content.addView(t("📧 تأكيد البريد الإلكتروني",27));
  content.addView(t("افتح بريدك الإلكتروني واضغط رابط التأكيد حتى يصبح حسابك فعالاً.",16),lp(5,10,5,15));
  Button resend=btn("إعادة إرسال رسالة التأكيد");
  Button back=btn("العودة لتسجيل الدخول");
  content.addView(resend,lp(8,5,8,5));content.addView(back,lp(8,5,8,5));
  resend.setOnClickListener(v->toast("يمكن إعادة الإرسال من Supabase Auth عند توفر البريد."));
  back.setOnClickListener(v->login());
 }
 void app(){
  base("ZaiTalk");
  LinearLayout nav=new LinearLayout(this);
  nav.setGravity(Gravity.CENTER);
  nav.setPadding(4,4,4,4);
  nav.setBackgroundColor(Color.rgb(15,24,40));
  String[] ns={"⌂","◉","＋","⌕","♡","✉","☻"};
  String[] labels={"الرئيسية","Reels","نشر","بحث","إشعارات","رسائل","حساب"};
  for(int i=0;i<ns.length;i++){
    final int k=i;
    LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);
    TextView icon=t(ns[i],20);icon.setGravity(Gravity.CENTER);TextView lab=t(labels[i],10);lab.setGravity(Gravity.CENTER);lab.setTextColor(MUTED);
    item.addView(icon);item.addView(lab);
    nav.addView(item,new LinearLayout.LayoutParams(0,66,1));
    item.setOnClickListener(v->{
      if(k==0)feed(); else if(k==1)reels(); else if(k==2)postDialog(); else if(k==3)search();
      else if(k==4)notifications(); else if(k==5)messages(); else profile();
    });
  }
  root.addView(nav);
  feed();
 }
 void feed(){content.removeAllViews();Button st=btn("⭕ الستوري");content.addView(st,lp(2,2,2,5));st.setOnClickListener(v->stories());content.addView(t("صباح الخير 👋",15));content.addView(t("آخر المنشورات",24));if(demo){post("ZaiTalk","مرحبا! هذه نسخة v10 الجديدة ❤️", "demo");post("ZaiTalk","الآن صار عندنا لايك وتعليق ومتابعة ورسائل كواجهة.", "demo");return;}work(()->{try{JSONArray a=db.select("posts","select=*&order=created_at.desc&limit=30");ui(()->{if(a.length()==0)post("ZaiTalk","ماكو منشورات بعد. انشر أول منشور!","");for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);post(o.optString("user_id","مستخدم"),o.optString("content",""),o.optString("id",""));}});}catch(Exception x){ui(()->toast("خطأ تحميل المنشورات: "+x.getMessage()));}});}
 void post(String user,String body,String id){
  LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,8,12,8);
  GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(22);c.setBackground(g);
  TextView u=t("●  @"+user,17);u.setTypeface(null,1);u.setTextColor(Color.rgb(235,242,250));c.addView(u);
  TextView b=t(body,16);c.addView(b);

  LinearLayout a=new LinearLayout(this);
  Button like=btn("♡ إعجاب 0"), com=btn("💬 0"), open=btn("عرض");
  like.setBackgroundColor(Color.TRANSPARENT);com.setBackgroundColor(Color.TRANSPARENT);open.setBackgroundColor(Color.TRANSPARENT);
  a.addView(like,new LinearLayout.LayoutParams(0,55,1));
  a.addView(com,new LinearLayout.LayoutParams(0,55,1));
  a.addView(open,new LinearLayout.LayoutParams(0,55,1));
  c.addView(a);content.addView(c,lp(2,7,2,7));

  if(!demo && id!=null && !id.isEmpty() && !id.equals("demo")){
    work(()->{
      try{
        org.json.JSONArray likes=db.select("likes","select=id&post_id=eq."+id);
        org.json.JSONArray comments=db.select("comments","select=id&post_id=eq."+id);
        ui(()->{like.setText("♡ إعجاب "+likes.length());com.setText("💬 "+comments.length());});
      }catch(Exception ignored){}
    });
  }
  like.setOnClickListener(v->{
    if(demo){like.setText("♥ إعجاب 1");return;}
    work(()->{
      try{
        org.json.JSONArray mine=db.select("likes","select=id&post_id=eq."+id+"&user_id=eq."+s.uid());
        if(mine.length()>0){
          db.delete("likes","id=eq."+mine.optJSONObject(0).optString("id"));
          ui(()->like.setText("♡ إعجاب"));
        }else{
          JSONObject q=new JSONObject();q.put("user_id",s.uid());q.put("post_id",id);db.insert("likes",q);
          ui(()->like.setText("♥ إعجاب"));
        }
      }catch(Exception x){ui(()->toast("تعذر تحديث الإعجاب"));}
    });
  });
  com.setOnClickListener(v->commentDialog(id));
  open.setOnClickListener(v->postDetails(id,user,body));
 }
 void postDetails(String id,String user,String body){
  base("المنشور");
  content.addView(t("@"+user,21));content.addView(t(body,18),lp(2,5,2,15));
  if(demo){content.addView(t("💬 التعليقات ستظهر هنا.",16));return;}
  work(()->{
    try{
      org.json.JSONArray a=db.select("comments","select=*&post_id=eq."+id+"&order=created_at.asc");
      ui(()->{
        content.addView(t("التعليقات ("+a.length()+")",20));
        for(int i=0;i<a.length();i++){
          JSONObject o=a.optJSONObject(i);
          content.addView(t("👤 "+o.optString("user_id","مستخدم")+"\n"+o.optString("content",""),15),lp(2,5,2,5));
        }
        Button b=btn("💬 إضافة تعليق");
        content.addView(b,lp(2,10,2,5));b.setOnClickListener(v->commentDialog(id));
      });
    }catch(Exception e){ui(()->toast("تعذر تحميل التعليقات"));}
  });
 }
 void postDialog(){final EditText e=inp("اكتب منشورك...",false);LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(15,10,15,10);b.addView(e);Button p=btn("نشر");b.addView(p,lp(0,10,0,0));Dialog d=new Dialog(this);d.setTitle("منشور جديد");d.setContentView(b);p.setOnClickListener(v->{String x=e.getText().toString().trim();if(x.isEmpty())return;d.dismiss();if(demo){post("أنت",x,"demo");return;}work(()->{try{JSONObject o=new JSONObject();o.put("user_id",s.uid());o.put("content",x);db.insert("posts",o);ui(this::feed);}catch(Exception z){ui(()->toast(z.getMessage()));}});});d.show();}
 void commentDialog(String postId){final EditText e=inp("اكتب تعليقك...",false);Button b=btn("إرسال");LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(15,10,15,10);l.addView(e);l.addView(b,lp(0,10,0,0));Dialog d=new Dialog(this);d.setTitle("التعليقات");d.setContentView(l);b.setOnClickListener(v->{String x=e.getText().toString().trim();if(x.isEmpty())return;d.dismiss();if(demo){toast("تمت إضافة التعليق تجريبياً");return;}work(()->{try{JSONObject o=new JSONObject();o.put("post_id",postId);o.put("user_id",s.uid());o.put("content",x);db.insert("comments",o);ui(()->toast("تم نشر التعليق"));}catch(Exception z){ui(()->toast(z.getMessage()));}});});d.show();}
 void search(){
  base("البحث");
  EditText e=inp("ابحث عن اسم مستخدم...",false);
  Button b=btn("🔎 بحث");
  content.addView(e,lp(4,5,4,5)); content.addView(b,lp(4,5,4,10));
  b.setOnClickListener(v->{
    String q=e.getText().toString().trim();
    if(q.isEmpty())return;
    content.addView(t("نتائج البحث: "+q,18));
    if(demo){userRow(q);return;}
    work(()->{
      try{
        org.json.JSONArray a=db.select("profiles","select=*&username=ilike.*"+q+"*&limit=30");
        ui(()->{for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);userRow(o.optString("username","مستخدم"));}});
      }catch(Exception x){ui(()->toast("تعذر البحث: "+x.getMessage()));}
    });
  });
 }
 void userRow(String name){
  LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);
  TextView u=t("👤 @"+name,17);
  Button view=btn("عرض");
  r.addView(u,new LinearLayout.LayoutParams(0,65,1));r.addView(view,new LinearLayout.LayoutParams(100,55));
  content.addView(r,lp(2,5,2,5));
  view.setOnClickListener(v->userProfile(name));
 }
 void userProfile(String username){
  base("@"+username);
  TextView av=t("👤",52);av.setGravity(Gravity.CENTER);content.addView(av);
  content.addView(t("@"+username,24),lp(3,3,3,2));
  TextView stats=t("منشورات     ...        متابعون     ...        يتابع     ...",16);content.addView(stats);
  if(!demo)work(()->{try{
    org.json.JSONArray p=db.select("posts","select=id&user_id=eq."+s.uid());
    org.json.JSONArray f=db.select("follows","select=id&following_id=eq."+s.uid());
    org.json.JSONArray g=db.select("follows","select=id&follower_id=eq."+s.uid());
    ui(()->stats.setText("منشورات     "+p.length()+"        متابعون     "+f.length()+"        يتابع     "+g.length()));
  }catch(Exception ignored){}});
  Button follow=btn("＋ متابعة");
  content.addView(follow,lp(20,10,20,10));
  if(demo){follow.setOnClickListener(v->{follow.setText("✓ متابَع");});}
  content.addView(t("منشورات المستخدم",20),lp(3,15,3,5));
  if(!demo){
    work(()->{
      try{
        org.json.JSONArray a=db.select("profiles","select=id,username&username=eq."+username+"&limit=1");
        if(a.length()>0){
          String uid=a.optJSONObject(0).optString("id","");
          org.json.JSONArray posts=db.select("posts","select=*&user_id=eq."+uid+"&order=created_at.desc&limit=30");
          ui(()->{
            for(int i=0;i<posts.length();i++){
              JSONObject p=posts.optJSONObject(i);
              post(username,p.optString("content",""),p.optString("id",""));
            }
          });
        }
      }catch(Exception e){ui(()->toast("تعذر تحميل الملف الشخصي"));}
    });
  }
  final String[] targetId={""};
  if(!demo){
    work(()->{try{
      org.json.JSONArray q=db.select("profiles","select=id&username=eq."+username+"&limit=1");
      if(q.length()>0)targetId[0]=q.optJSONObject(0).optString("id","");
    }catch(Exception ignored){}});
  }
  follow.setOnClickListener(v->{
    if(demo){follow.setText("✓ متابَع");return;}
    if(targetId[0].isEmpty()||targetId[0].equals(s.uid())){toast("لا يمكن متابعة هذا الحساب");return;}
    work(()->{try{
      org.json.JSONArray mine=db.select("follows","select=id&follower_id=eq."+s.uid()+"&following_id=eq."+targetId[0]);
      if(mine.length()>0){
        db.delete("follows","id=eq."+mine.optJSONObject(0).optString("id"));
        ui(()->follow.setText("＋ متابعة"));
      }else{
        JSONObject o=new JSONObject();o.put("follower_id",s.uid());o.put("following_id",targetId[0]);db.insert("follows",o);
        JSONObject n=new JSONObject();n.put("user_id",targetId[0]);n.put("actor_id",s.uid());n.put("type","follow");db.insert("notifications",n);
        ui(()->follow.setText("✓ متابَع"));
      }
    }catch(Exception e){ui(()->toast("تعذر تحديث المتابعة"));}});
  });
 }
 void messages(){
  base("الرسائل");
  content.addView(t("💬 محادثاتك",25));
  if(demo){
    Button b=btn("فتح محادثة تجريبية");
    content.addView(b,lp(4,12,4,5));
    b.setOnClickListener(v->chat("demo"));
    return;
  }
  work(()->{
    try{
      org.json.JSONArray a=db.select("conversation_members","select=conversation_id&user_id=eq."+s.uid());
      ui(()->{
        if(a.length()==0){
          content.addView(t("ما عندك محادثات بعد. بعد إنشاء محادثة ستظهر هنا.",16));
        }
        for(int i=0;i<a.length();i++){
          JSONObject o=a.optJSONObject(i);
          String cid=o.optString("conversation_id","");
          Button b=btn("💬 محادثة "+(i+1));
          content.addView(b,lp(3,6,3,6));
          b.setOnClickListener(v->chat(cid));
        }
      });
    }catch(Exception e){ui(()->toast("تعذر تحميل المحادثات: "+e.getMessage()));}
  });
 }
 void chat(String conversationId){
  base("محادثة");
  content.addView(t("💬 ZaiTalk Chat",22));
  LinearLayout messagesBox=new LinearLayout(this);
  messagesBox.setOrientation(LinearLayout.VERTICAL);
  content.addView(messagesBox);
  EditText e=inp("اكتب رسالة...",false);
  Button send=btn("إرسال");
    Button media=btn("📎");
  content.addView(e);
  content.addView(send,lp(4,8,4,8));

  if(!demo && conversationId!=null && !conversationId.equals("demo")){
    work(()->{
      try{
        org.json.JSONArray a=db.select("messages","select=*&conversation_id=eq."+conversationId+"&order=created_at.asc&limit=100");
        ui(()->{
          for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            String who=o.optString("sender_id","").equals(s.uid())?"أنت":"مستخدم";
            messagesBox.addView(t(who+": "+o.optString("content",""),15),lp(2,3,2,3));
          }
        });
      }catch(Exception x){ui(()->toast("تعذر تحميل الرسائل"));}
    });
  }

  send.setOnClickListener(v->{
    String text=e.getText().toString().trim();
    if(text.isEmpty())return;
    if(demo || conversationId==null || conversationId.equals("demo")){
      messagesBox.addView(t("أنت: "+text,16),lp(2,3,2,3));
      e.setText("");
      return;
    }
    work(()->{
      try{
        JSONObject o=new JSONObject();
        o.put("conversation_id",conversationId);
        o.put("sender_id",s.uid());
        o.put("content",text);
        db.insert("messages",o);
        ui(()->{messagesBox.addView(t("أنت: "+text,16),lp(2,3,2,3));e.setText("");});
      }catch(Exception x){ui(()->toast("فشل إرسال الرسالة: "+x.getMessage()));}
    });
  });
 }
 void explore(){
  base("Explore");
  content.addView(t("🔥 استكشاف",27));
  content.addView(t("اكتشف أحدث المحتوى والمستخدمين على ZaiTalk",15));
  if(demo){
    post("ZaiTalk","منشور رائج في Explore 🔥","demo");
    post("ZaiTalk","محتوى جديد من المجتمع","demo");
    return;
  }
  work(()->{
    try{
      org.json.JSONArray a=db.select("posts","select=*&order=created_at.desc&limit=50");
      ui(()->{
        if(a.length()==0)content.addView(t("لا يوجد محتوى بعد.",16));
        for(int i=0;i<a.length();i++){
          JSONObject o=a.optJSONObject(i);
          post(o.optString("user_id","مستخدم"),o.optString("content",""),o.optString("id",""));
        }
      });
    }catch(Exception e){ui(()->toast("تعذر تحميل Explore"));}
  });
 }
 void reels(){
  base("Reels");
  content.addView(t("🎬 فيديوهات قصيرة",25));
  if(demo){
    reelCard("ZaiTalk","فيديو تجريبي قصير — هنا راح تظهر الـ Reels");
    reelCard("ZaiTalk","واجهة الفيديو جاهزة للربط مع Storage");
    return;
  }
  work(()->{
    try{
      org.json.JSONArray a=db.select("posts","select=*&media_url=not.is.null&order=created_at.desc&limit=30");
      ui(()->{
        if(a.length()==0) content.addView(t("ماكو Reels بعد. ارفع فيديو من زر الوسائط.",16));
        for(int i=0;i<a.length();i++){
          JSONObject o=a.optJSONObject(i);
          reelCard(o.optString("user_id","مستخدم"),o.optString("content",""));
        }
      });
    }catch(Exception e){ui(()->toast("تعذر تحميل Reels"));}
  });
 }
 void reelCard(String user,String text){
  LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(14,14,14,14);
  GradientDrawable g=new GradientDrawable();g.setColor(CARD);g.setCornerRadius(25);c.setBackground(g);
  TextView video=t("▶\\n\\n"+text+"\\n\\n♡   💬   ↗",20);video.setGravity(Gravity.CENTER);video.setMinHeight(420);video.setTextSize(19);
  c.addView(t("@"+user,17));c.addView(video);content.addView(c,lp(2,8,2,8));
 }
 void profile(){
  base("حسابي");
  TextView avatar=t("👤",56);avatar.setGravity(Gravity.CENTER);content.addView(avatar);
  TextView name=t("@zaitalk_user",22);name.setGravity(Gravity.CENTER);content.addView(name);
  TextView stats=t("منشورات     ...        متابعون     ...        يتابع     ...",15);stats.setGravity(Gravity.CENTER);content.addView(stats);
  content.addView(t("نبذة عن الحساب\nشارك يومياتك ومحتواك على ZaiTalk.",15),lp(5,8,5,10));

  Button edit=btn("✏️ تعديل الحساب");
  Button settings=btn("⚙️ الإعدادات");
  Button logout=btn("تسجيل الخروج");
  content.addView(edit,lp(15,5,15,5));
  content.addView(settings,lp(15,5,15,5));
  content.addView(logout,lp(15,5,15,15));

  if(!demo)work(()->{
    try{
      org.json.JSONArray a=db.select("profiles","select=*&id=eq."+s.uid()+"&limit=1");
      ui(()->{
        if(a.length()>0){
          JSONObject p=a.optJSONObject(0);
          name.setText("@"+p.optString("username","zaitalk_user"));
        }
      });
      org.json.JSONArray posts=db.select("posts","select=id&user_id=eq."+s.uid());
      org.json.JSONArray followers=db.select("follows","select=id&following_id=eq."+s.uid());
      org.json.JSONArray following=db.select("follows","select=id&follower_id=eq."+s.uid());
      ui(()->stats.setText("منشورات     "+posts.length()+"        متابعون     "+followers.length()+"        يتابع     "+following.length()));
    }catch(Exception ignored){}
  });

  edit.setOnClickListener(v->editProfileDialog());
  settings.setOnClickListener(v->settingsPage());
  logout.setOnClickListener(v->{s.clear();db.token("");storage.token("");login();});
 }
 void editProfileDialog(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(15,10,15,10);
  EditText username=inp("اسم المستخدم",false),bio=inp("النبذة",false);
  box.addView(username);box.addView(bio,lp(0,8,0,8));Button save=btn("حفظ");
  box.addView(save);
  Dialog d=new Dialog(this);d.setTitle("تعديل الحساب");d.setContentView(box);
  save.setOnClickListener(v->{
    String u=username.getText().toString().trim(), b=bio.getText().toString().trim();
    if(u.isEmpty())return; d.dismiss();
    if(demo){toast("تم حفظ التعديل تجريبياً");return;}
    work(()->{try{
      JSONObject o=new JSONObject();o.put("username",u);o.put("bio",b);
      db.patch("profiles","id=eq."+s.uid(),o);
      ui(()->{toast("تم تحديث الحساب");profile();});
    }catch(Exception e){ui(()->toast("تعذر تحديث الحساب: "+e.getMessage()));}});
  });
  d.show();
 }
 void changePasswordDialog(){
  EditText p1=inp("كلمة المرور الجديدة",true),p2=inp("تأكيد كلمة المرور",true);
  Button b=btn("تغيير كلمة المرور");
  LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(15,10,15,10);
  l.addView(p1);l.addView(p2,lp(0,8,0,8));l.addView(b);
  Dialog d=new Dialog(this);d.setTitle("تغيير كلمة المرور");d.setContentView(l);
  b.setOnClickListener(v->{
    String a=p1.getText().toString(),c=p2.getText().toString();
    if(a.length()<6||!a.equals(c)){toast("تأكد من كلمة المرور الجديدة");return;}
    if(demo){d.dismiss();toast("تم التغيير تجريبياً");return;}
    work(()->{try{db.updatePassword(a);ui(()->{d.dismiss();toast("تم تغيير كلمة المرور");});}
    catch(Exception e){ui(()->toast("تعذر تغيير كلمة المرور: "+e.getMessage()));}});
  }); d.show();
 }
 void settingsPage(){
  base("الإعدادات");
  content.addView(t("⚙️ إعدادات ZaiTalk",25)); content.addView(t("حالة الحساب: متصل",14));
  content.addView(t("الحساب",19),lp(3,15,3,5));
  Button account=btn("تعديل بيانات الحساب"); Button pass=btn("🔑 تغيير كلمة المرور");
  Button notifications=btn("إعدادات الإشعارات");
  Button privacy=btn("الخصوصية");
  Button about=btn("عن ZaiTalk"); Button blocked=btn("🚫 المستخدمون المحظورون"); Button report=btn("⚠️ الإبلاغ عن مشكلة");
  content.addView(account,lp(5,5,5,5)); content.addView(pass,lp(5,5,5,5));content.addView(notifications,lp(5,5,5,5));
  content.addView(privacy,lp(5,5,5,5));content.addView(about,lp(5,5,5,5)); content.addView(blocked,lp(5,5,5,5));content.addView(report,lp(5,5,5,5));
  account.setOnClickListener(v->editProfileDialog()); pass.setOnClickListener(v->changePasswordDialog());
  notifications.setOnClickListener(v->toast("إعدادات الإشعارات جاهزة للتوسعة"));
  privacy.setOnClickListener(v->toast("إعدادات الخصوصية جاهزة للتوسعة"));
  about.setOnClickListener(v->toast("ZaiTalk — Social App")); blocked.setOnClickListener(v->blockedUsers()); report.setOnClickListener(v->reportDialog());
 }
 void followUser(String targetUserId){
  if(demo){toast("تمت المتابعة تجريبياً");return;}
  work(()->{
   try{
    JSONObject o=new JSONObject();o.put("follower_id",s.uid());o.put("following_id",targetUserId);
    db.insert("follows",o);
    JSONObject n=new JSONObject();n.put("user_id",targetUserId);n.put("actor_id",s.uid());n.put("type","follow");
    db.insert("notifications",n);
    ui(()->toast("تمت المتابعة"));
   }catch(Exception e){ui(()->toast("تعذر المتابعة: "+e.getMessage()));}
  });
 }
 void notifyLike(String ownerId,String postId){
  if(demo)return;
  work(()->{try{
   JSONObject n=new JSONObject();n.put("user_id",ownerId);n.put("actor_id",s.uid());n.put("type","like");n.put("post_id",postId);
   db.insert("notifications",n);
  }catch(Exception ignored){}});
 }


 void emptyState(String title,String subtitle){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);
  TextView a=t("✨",48);a.setGravity(Gravity.CENTER);box.addView(a);
  TextView b=t(title,21);b.setGravity(Gravity.CENTER);box.addView(b);
  TextView c=t(subtitle,14);c.setTextColor(MUTED);c.setGravity(Gravity.CENTER);box.addView(c);
  content.addView(box,lp(10,60,10,30));
 }

 void work(Runnable r){ex.execute(r);}void ui(Runnable r){runOnUiThread(r);}void toast(String x){Toast.makeText(this,x,Toast.LENGTH_LONG).show();}
 @Override protected void onDestroy(){ex.shutdownNow();super.onDestroy();}

  // v27: Integrated live chat screen. Pass a conversation id and user access token.
  public void openLiveChat(String conversationId){
    base("محادثة مباشرة");
    content.addView(t("💬 المحادثة المباشرة",25));
    TextView status=t("🟡 جاري الاتصال...",14);
    content.addView(status);

    LinearLayout messagesBox=new LinearLayout(this);
    messagesBox.setOrientation(LinearLayout.VERTICAL);
    ScrollView scroll=new ScrollView(this);
    scroll.addView(messagesBox);
    content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

    LinearLayout composer=new LinearLayout(this);
    EditText input=new EditText(this);
    input.setHint("اكتب رسالة...");
    input.setTextColor(Color.WHITE);
    input.setHintTextColor(Color.GRAY);
    Button send=btn("إرسال");
    Button media=btn("📎");
    composer.addView(input,new LinearLayout.LayoutParams(0,-2,1));
    composer.addView(media,new LinearLayout.LayoutParams(-2,-2));
    composer.addView(send,new LinearLayout.LayoutParams(-2,-2));
    media.setOnClickListener(v->pickChatMedia(conversationId));
    content.addView(composer);

    String token=SessionStore.get(this);
    LiveChatController live=new LiveChatController("realtime:conversation:"+conversationId);
    live.start(SupabaseConfig.URL,SupabaseConfig.KEY,token,new LiveChatController.Listener(){
      public void connected(){runOnUiThread(()->status.setText("🟢 متصل الآن"));}
      public void error(String m){runOnUiThread(()->status.setText("🔴 انقطع الاتصال"));}
      public void newMessage(org.json.JSONObject row){
        runOnUiThread(()->{
          String body=row.optString("content",row.optString("message",""));
          String mediaUrl=row.optString("media_url","");
          String mediaType=row.optString("media_type","");
          String status=row.optString("status","sent");
          renderChatMessage(messagesBox,"💬",body,mediaUrl,mediaType);
          if(!status.isEmpty()) messagesBox.addView(t(messageStatus(status),11));
          scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
        });
      }
    });

    send.setOnClickListener(v->{
      String text=input.getText().toString().trim();
      if(text.isEmpty()) return;
      input.setText("");
      new Thread(()->{
        try{
          org.json.JSONObject row=new org.json.JSONObject();
          row.put("conversation_id",conversationId);
          row.put("content",text);
          SupabaseClient.insert("messages",row.toString());
          runOnUiThread(()->{
            renderChatMessage(messagesBox,"أنت",text,"","");

            scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
          });
        }catch(Exception e){
          runOnUiThread(()->toast("تعذر إرسال الرسالة"));
        }
      }).start();
    });
  }

  static final int CHAT_MEDIA_PICK=9012;
  String pendingConversationId="";

  public void pickChatMedia(String conversationId){
    pendingConversationId=conversationId;
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("*/*");
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
    startActivityForResult(i,CHAT_MEDIA_PICK);
  }

  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode!=CHAT_MEDIA_PICK || resultCode!=RESULT_OK || data==null || data.getData()==null) return;
    Uri uri=data.getData();
    new Thread(()->{
      try{
        String name="chat_"+System.currentTimeMillis()+"_media";
        String path=uri.toString();
        String publicUrl=path;
        // The selected URI is kept for preview; actual byte upload is delegated to the uploader layer.
        runOnUiThread(()->showMediaPreview(pendingConversationId,publicUrl));
      }catch(Exception e){runOnUiThread(()->toast("تعذر اختيار الوسائط"));}
    }).start();
  }

  void showMediaPreview(String conversationId,String uri){
    Uri selected=Uri.parse(uri);
    new AlertDialog.Builder(this)
      .setTitle("معاينة الوسائط")
      .setMessage("هل تريد إرسال الملف داخل المحادثة؟")
      .setPositiveButton("إرسال",(d,w)->uploadChatMedia(conversationId,selected))
      .setNegativeButton("إلغاء",null).show();
  }

  void uploadChatMedia(String conversationId,Uri uri){
    new Thread(()->{
      try{
        String ext="bin";
        String mime=getContentResolver().getType(uri);
        if(mime!=null){
          if(mime.contains("png")) ext="png";
          else if(mime.contains("webp")) ext="webp";
          else if(mime.contains("mp4")) ext="mp4";
          else if(mime.contains("quicktime")) ext="mov";
          else if(mime.contains("image")) ext="jpg";
        }
        String objectPath=SessionStore.getUserId()+"/chat_"+System.currentTimeMillis()+"."+ext;
        String publicUrl=ChatMediaUploader.upload(this,uri,"chat-media",objectPath);

        org.json.JSONObject row=new org.json.JSONObject();
        row.put("conversation_id",conversationId);
        row.put("content","");
        row.put("media_url",publicUrl);
        row.put("media_type",mime==null?"file":(mime.startsWith("video")?"video":"image"));
        SupabaseClient.insert("messages",row.toString());

        runOnUiThread(()->toast("تم إرسال الوسائط ✅"));
      }catch(Exception e){
        runOnUiThread(()->toast("فشل رفع الوسائط: "+e.getMessage()));
      }
    }).start();
  }


  void addChatMediaView(LinearLayout box,String mediaUrl,String mediaType){
    if(mediaUrl==null || mediaUrl.isEmpty()) return;
    if("audio".equalsIgnoreCase(mediaType)){
      box.addView(VoiceMessageView.create(this,mediaUrl));
      return;
    }
    if("video".equalsIgnoreCase(mediaType)){
      VideoView vv=new VideoView(this);
      vv.setVideoURI(Uri.parse(mediaUrl));
      vv.setMediaController(new android.widget.MediaController(this));
      vv.setLayoutParams(new LinearLayout.LayoutParams(-1,420));
      box.addView(vv);
      vv.setOnPreparedListener(mp->{mp.setLooping(false);});
    } else {
      ImageView iv=new ImageView(this);
      iv.setLayoutParams(new LinearLayout.LayoutParams(-1,420));
      iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
      // Android's ImageView does not fetch HTTP URLs itself; use a tiny async downloader.
      new Thread(()->{
        try{
          java.net.URL u=new java.net.URL(mediaUrl);
          java.net.HttpURLConnection c=(java.net.HttpURLConnection)u.openConnection();
          c.setConnectTimeout(10000); c.setReadTimeout(15000);
          java.io.InputStream in=c.getInputStream();
          android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);
          in.close();
          runOnUiThread(()->iv.setImageBitmap(bm));
        }catch(Exception e){
          runOnUiThread(()->iv.setImageResource(android.R.drawable.ic_menu_report_image));
        }
      }).start();
      box.addView(iv);
    }
  }

  void renderChatMessage(LinearLayout box,String sender,String content,String mediaUrl,String mediaType){
    TextView tv=t((sender==null?"":sender)+": "+(content==null?"":content),15);
    box.addView(tv);
    addChatMediaView(box,mediaUrl,mediaType);
  }

  VoiceRecorder voiceRecorder;
  String activeVoiceConversation="";

  public void startVoiceMessage(String conversationId){
    activeVoiceConversation=conversationId;
    if(android.os.Build.VERSION.SDK_INT>=23 &&
       checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
      requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7311);
      return;
    }
    try{
      if(voiceRecorder==null) voiceRecorder=new VoiceRecorder();
      voiceRecorder.start(this);
      toast("🎙️ التسجيل بدأ — اضغط زر الصوت مرة ثانية للإيقاف");
    }catch(Exception e){toast("تعذر بدء التسجيل");}
  }

  public void stopVoiceMessage(){
    if(voiceRecorder==null) return;
    String path=voiceRecorder.stop();
    if(path==null) return;
    String conv=activeVoiceConversation;
    new Thread(()->{
      try{
        String objectPath=SessionStore.getUserId()+"/voice_"+System.currentTimeMillis()+".m4a";
        String url=VoiceRecorder.upload(this,path,"chat-media",objectPath);
        org.json.JSONObject row=new org.json.JSONObject();
        row.put("conversation_id",conv);
        row.put("content","");
        row.put("media_url",url);
        row.put("media_type","audio");
        SupabaseClient.insert("messages",row.toString());
        runOnUiThread(()->toast("تم إرسال الرسالة الصوتية ✅"));
      }catch(Exception e){runOnUiThread(()->toast("فشل إرسال الصوت"));}
    }).start();
  }

  PresenceManager presenceManager;
  @Override protected void onStart(){
    super.onStart();
    if(presenceManager==null) presenceManager=new PresenceManager(this);
    new PrivacySync(this).loadFromCloud();
    if(new PrivacyManager(this).showOnline()) presenceManager.setOnline();
  }
  @Override protected void onStop(){
    if(presenceManager!=null && new PrivacyManager(this).showOnline()) presenceManager.setOffline();
    super.onStop();
  }

  void markMessageRead(String messageId){
    if(!new PrivacyManager(this).readReceipts()) return;
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("status","read");
        p.put("read_at",new PresenceManager(this).nowIso());
        SupabaseClient.patch("messages?id=eq."+messageId,p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  String messageStatus(String status){
    if("read".equalsIgnoreCase(status)) return "✓✓ تمت القراءة";
    if("delivered".equalsIgnoreCase(status)) return "✓✓ تم التسليم";
    return "✓ تم الإرسال";
  }

  void privacySettings(){
    base("الخصوصية");
    content.addView(t("🔒 الخصوصية",27));
    content.addView(t("تحكم بالمعلومات التي تظهر للآخرين.",15));

    PrivacyManager pm=new PrivacyManager(this);

    Switch lastSeen=new Switch(this);
    lastSeen.setText("إظهار آخر ظهور");
    lastSeen.setTextColor(Color.WHITE);
    lastSeen.setChecked(pm.showLastSeen());
    content.addView(lastSeen);

    Switch online=new Switch(this);
    online.setText("إظهار حالة الاتصال");
    online.setTextColor(Color.WHITE);
    online.setChecked(pm.showOnline());
    content.addView(online);

    Switch receipts=new Switch(this);
    receipts.setText("إيصالات قراءة الرسائل");
    receipts.setTextColor(Color.WHITE);
    receipts.setChecked(pm.readReceipts());
    content.addView(receipts);

    lastSeen.setOnCheckedChangeListener((b,v)->{pm.set("show_last_seen",v); new PrivacySync(this).saveToCloud();});
    online.setOnCheckedChangeListener((b,v)->{pm.set("show_online",v); new PrivacySync(this).saveToCloud();});
    receipts.setOnCheckedChangeListener((b,v)->{pm.set("read_receipts",v); new PrivacySync(this).saveToCloud();});

    Button save=btn("حفظ");
    content.addView(save);
    save.setOnClickListener(v->{toast("تم حفظ إعدادات الخصوصية ✅");});
  }

  void blockUserDialog(String userId,String username){
    new AlertDialog.Builder(this)
      .setTitle("حظر المستخدم")
      .setMessage("هل تريد حظر "+username+"؟ لن تتمكن من مراسلته أو التفاعل معه.")
      .setPositiveButton("حظر",(d,w)->{
        new BlockManager(this).block(userId);
        toast("تم حظر المستخدم");
      })
      .setNegativeButton("إلغاء",null).show();
  }

  void unblockUser(String userId){
    new BlockManager(this).unblock(userId);
    toast("تم إلغاء الحظر");
  }

  void blockedUsers(){
    base("المحظورون");
    content.addView(t("🚫 المستخدمون المحظورون",25));
    TextView info=t("تظهر هنا قائمة الأشخاص الذين حظرتهم.",15);
    content.addView(info);
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        String raw=SupabaseClient.select("blocks?blocker_id=eq."+uid+"&select=blocked_id");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        runOnUiThread(()->{
          try{
            if(a.length()==0){content.addView(t("لا يوجد مستخدمون محظورون.",15));return;}
            for(int i=0;i<a.length();i++){
              String id=a.getJSONObject(i).optString("blocked_id");
              Button b=btn("إلغاء حظر "+id);
              content.addView(b);
              b.setOnClickListener(v->{new BlockManager(this).unblock(id); b.setText("تم إلغاء الحظر"); b.setEnabled(false);});
            }
          }catch(Exception ignored){}
        });
      }catch(Exception e){runOnUiThread(()->toast("تعذر تحميل القائمة"));}
    }).start();
  }

  void reportUserDialog(String userId){
    String[] reasons={"محتوى غير مناسب","إزعاج أو مضايقة","حساب مزيف","رسائل مزعجة","سبب آخر"};
    new AlertDialog.Builder(this)
      .setTitle("إبلاغ عن المستخدم")
      .setItems(reasons,(d,w)->{
        new ReportManager(this).reportUser(userId,reasons[w]);
        toast("تم إرسال البلاغ للمراجعة");
      }).show();
  }

  void reportPostDialog(String postId){
    String[] reasons={"محتوى غير مناسب","معلومات مضللة","انتهاك حقوق","إزعاج أو سبام","سبب آخر"};
    new AlertDialog.Builder(this)
      .setTitle("إبلاغ عن المنشور")
      .setItems(reasons,(d,w)->{
        new ReportManager(this).reportPost(postId,reasons[w]);
        toast("تم إرسال البلاغ للمراجعة");
      }).show();
  }

  void openAdminPanel(){
    new Thread(()->{
      AdminManager am=new AdminManager(this);
      if(!am.isAdmin()){
        runOnUiThread(()->toast("غير مصرح لك بدخول لوحة الإدارة"));
        return;
      }
      try{
        String raw=am.reports();
        runOnUiThread(()->showAdminReports(raw));
      }catch(Exception e){
        runOnUiThread(()->toast("تعذر تحميل البلاغات"));
      }
    }).start();
  }

  void showAdminReports(String raw){
    base("لوحة الإدارة");
    content.addView(t("🛡️ لوحة Admin",27));
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      if(a.length()==0){content.addView(t("لا توجد بلاغات حالياً.",16));return;}
      for(int i=0;i<a.length();i++){
        org.json.JSONObject r=a.getJSONObject(i);
        String id=r.optString("id");
        String type=r.optString("target_type");
        String reason=r.optString("reason");
        String status=r.optString("status");
        TextView card=t("🚩 "+type+"\\nالسبب: "+reason+"\\nالحالة: "+status,15);
        card.setPadding(16,16,16,16);
        content.addView(card);
        Button review=btn("مراجعة البلاغ");
        content.addView(review);
        review.setOnClickListener(v->adminReviewDialog(id));
      }
    }catch(Exception e){content.addView(t("بيانات البلاغات غير صالحة.",15));}
  }

  void adminReviewDialog(String reportId){
    String[] states={"reviewed","resolved","dismissed"};
    new AlertDialog.Builder(this)
      .setTitle("إدارة البلاغ")
      .setItems(states,(d,w)->{
        new AdminManager(this).updateReport(reportId,states[w],"تمت المراجعة من لوحة الإدارة");
        toast("تم تحديث البلاغ");
      }).show();
  }

  void adminUsers(){
    new Thread(()->{
      AdminManager am=new AdminManager(this);
      if(!am.isAdmin()){runOnUiThread(()->toast("غير مصرح"));return;}
      try{String raw=am.users();runOnUiThread(()->showAdminUsers(raw));}
      catch(Exception e){runOnUiThread(()->toast("تعذر تحميل المستخدمين"));}
    }).start();
  }

  void showAdminUsers(String raw){
    base("إدارة المستخدمين");
    content.addView(t("👥 المستخدمون",26));
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      for(int i=0;i<a.length();i++){
        org.json.JSONObject u=a.getJSONObject(i);
        String id=u.optString("id"), name=u.optString("username","بدون اسم"), role=u.optString("role","user");
        content.addView(t("👤 "+name+"\\nالدور: "+role,15));
        Button b=btn("تغيير الدور");
        content.addView(b);
        b.setOnClickListener(v->changeRoleDialog(id,role));
      }
    }catch(Exception e){toast("بيانات المستخدمين غير صالحة");}
  }

  void changeRoleDialog(String userId,String current){
    String[] roles={"user","moderator","admin"};
    new AlertDialog.Builder(this).setTitle("صلاحية المستخدم")
      .setItems(roles,(d,w)->{
        new AdminManager(this).setUserRole(userId,roles[w]);
        toast("تم تحديث الصلاحية");
      }).show();
  }

  void adminPosts(){
    new Thread(()->{
      AdminManager am=new AdminManager(this);
      if(!am.isAdmin()){runOnUiThread(()->toast("غير مصرح"));return;}
      try{String raw=am.posts();runOnUiThread(()->showAdminPosts(raw));}
      catch(Exception e){runOnUiThread(()->toast("تعذر تحميل المنشورات"));}
    }).start();
  }

  void showAdminPosts(String raw){
    base("إدارة المنشورات");
    content.addView(t("📝 المنشورات",26));
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      for(int i=0;i<a.length();i++){
        org.json.JSONObject p=a.getJSONObject(i);
        String id=p.optString("id"), body=p.optString("content","");
        content.addView(t(body,15));
        Button del=btn("حذف المنشور");
        content.addView(del);
        del.setOnClickListener(v->{
          new AlertDialog.Builder(this).setTitle("حذف المنشور؟")
            .setMessage("سيتم حذف المنشور من قاعدة البيانات.")
            .setPositiveButton("حذف",(d,w)->{
              new AdminManager(this).deletePost(id);
              del.setText("تم الحذف"); del.setEnabled(false);
            }).setNegativeButton("إلغاء",null).show();
        });
      }
    }catch(Exception e){toast("بيانات المنشورات غير صالحة");}
  }

  void verificationRequest(){
    final EditText input=new EditText(this);
    input.setHint("اكتب سبب طلب التوثيق");
    input.setTextColor(Color.WHITE);
    input.setHintTextColor(Color.GRAY);
    new AlertDialog.Builder(this)
      .setTitle("☑️ طلب توثيق الحساب")
      .setMessage("أرسل طلبك للمشرف لمراجعة الحساب.")
      .setView(input)
      .setPositiveButton("إرسال",(d,w)->{
        new VerificationManager(this).request(input.getText().toString());
        toast("تم إرسال طلب التوثيق للمراجعة");
      }).setNegativeButton("إلغاء",null).show();
  }

  void adminVerificationRequests(){
    new Thread(()->{
      AdminManager am=new AdminManager(this);
      if(!am.isAdmin()){runOnUiThread(()->toast("غير مصرح"));return;}
      try{
        String raw=SupabaseClient.select("verification_requests?select=*&order=created_at.desc");
        runOnUiThread(()->showVerificationRequests(raw));
      }catch(Exception e){runOnUiThread(()->toast("تعذر تحميل طلبات التوثيق"));}
    }).start();
  }

  void showVerificationRequests(String raw){
    base("طلبات التوثيق");
    content.addView(t("☑️ طلبات التوثيق",26));
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      if(a.length()==0){content.addView(t("لا توجد طلبات.",15));return;}
      for(int i=0;i<a.length();i++){
        org.json.JSONObject r=a.getJSONObject(i);
        String id=r.optString("id"), uid=r.optString("user_id"), status=r.optString("status");
        content.addView(t("المستخدم: "+uid+"\\nالحالة: "+status+"\\nالسبب: "+r.optString("note",""),14));
        Button approve=btn("موافقة");
        Button reject=btn("رفض");
        content.addView(approve); content.addView(reject);
        approve.setOnClickListener(v->reviewVerification(id,uid,true,approve,reject));
        reject.setOnClickListener(v->reviewVerification(id,uid,false,approve,reject));
      }
    }catch(Exception e){toast("بيانات الطلبات غير صالحة");}
  }

  void reviewVerification(String requestId,String userId,boolean approve,Button a,Button r){
    new Thread(()->{
      try{
        org.json.JSONObject rp=new org.json.JSONObject();
        rp.put("status",approve?"approved":"rejected");
        SupabaseClient.patch("verification_requests?id=eq."+requestId,rp.toString());

        org.json.JSONObject up=new org.json.JSONObject();
        up.put("is_verified",approve);
        SupabaseClient.patch("profiles?id=eq."+userId,up.toString());

        runOnUiThread(()->{
          a.setEnabled(false); r.setEnabled(false);
          toast(approve?"تم توثيق الحساب ✅":"تم رفض الطلب");
        });
      }catch(Exception e){runOnUiThread(()->toast("تعذر تحديث الطلب"));}
    }).start();
  }

  void privateAccountSettings(){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select("profiles?id=eq."+SessionStore.getUserId()+"&select=is_private");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        boolean current=a.length()>0 && a.getJSONObject(0).optBoolean("is_private",false);
        runOnUiThread(()->showPrivateSetting(current));
      }catch(Exception e){runOnUiThread(()->showPrivateSetting(false));}
    }).start();
  }

  void showPrivateSetting(boolean current){
    base("الحساب الخاص");
    content.addView(t("🔒 خصوصية الحساب",26));
    Switch sw=new Switch(this);
    sw.setText("حساب خاص");
    sw.setTextColor(Color.WHITE);
    sw.setChecked(current);
    content.addView(sw);
    content.addView(t("عند تفعيل الحساب الخاص، تحتاج طلبات المتابعة إلى موافقة منك.",14));
    sw.setOnCheckedChangeListener((b,v)->{
      new FollowManager(this).setPrivate(v);
      toast(v?"تم تحويل الحساب إلى خاص":"تم تحويل الحساب إلى عام");
    });
  }

  void followPrivateUser(String userId){
    new FollowManager(this).request(userId);
    toast("تم إرسال طلب المتابعة");
  }

  void followRequests(){
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        String raw=SupabaseClient.select("follow_requests?following_id=eq."+uid+"&status=eq.pending&select=*");
        runOnUiThread(()->showFollowRequests(raw));
      }catch(Exception e){runOnUiThread(()->toast("تعذر تحميل طلبات المتابعة"));}
    }).start();
  }

  void showFollowRequests(String raw){
    base("طلبات المتابعة");
    content.addView(t("👥 طلبات المتابعة",26));
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      if(a.length()==0){content.addView(t("لا توجد طلبات حالياً.",15));return;}
      for(int i=0;i<a.length();i++){
        org.json.JSONObject r=a.getJSONObject(i);
        String id=r.optString("id"), from=r.optString("follower_id");
        content.addView(t("طلب من: "+from,15));
        Button accept=btn("قبول");
        Button reject=btn("رفض");
        content.addView(accept); content.addView(reject);
        accept.setOnClickListener(v->{new FollowManager(this).approve(id); accept.setEnabled(false); reject.setEnabled(false); toast("تم قبول الطلب");});
        reject.setOnClickListener(v->{new FollowManager(this).reject(id); accept.setEnabled(false); reject.setEnabled(false); toast("تم رفض الطلب");});
      }
    }catch(Exception e){toast("بيانات الطلبات غير صالحة");}
  }

  void notificationsCenter(){
    base("الإشعارات");
    content.addView(t("🔔 الإشعارات",26));
    LinearLayout list=new LinearLayout(this);
    list.setOrientation(LinearLayout.VERTICAL);
    content.addView(list);
    new NotificationManagerZT(this).load(list);
  }

  void refreshNotificationBadge(TextView badge){
    new NotificationManagerZT(this).unreadCount(badge);
  }

  private NotificationRealtime notificationRealtime;

  @Override protected void onStart(){
    super.onStart();
    notificationRealtime=new NotificationRealtime(this);
    notificationRealtime.connect();
  }

  @Override protected void onStop(){
    if(notificationRealtime!=null) notificationRealtime.close();
    super.onStop();
  }

  private void handleNotificationIntent(android.content.Intent intent){
    if(intent==null)return;
    String type=intent.getStringExtra("notification_type");
    String ref=intent.getStringExtra("notification_ref");
    if(type==null)return;

    if("follow_request".equals(type)){
      followRequests();
    }else if("follow_accepted".equals(type) || "follow_rejected".equals(type)){
      notificationsCenter();
    }else if("message".equals(type)){
      notificationsCenter();
    }else{
      notificationsCenter();
    }
  }

  @Override protected void onNewIntent(android.content.Intent intent){
    super.onNewIntent(intent);
    setIntent(intent);
    handleNotificationIntent(intent);
  }

  private ProNavigation proNavigation;

  public void setupProNavigation(){
    proNavigation=new ProNavigation(this);
    proNavigation.setup();
  }
}