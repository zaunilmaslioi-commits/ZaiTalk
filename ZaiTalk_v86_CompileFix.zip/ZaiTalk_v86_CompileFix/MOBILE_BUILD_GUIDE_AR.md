# بناء ZaiTalk من الهاتف فقط

هذه الطريقة تستخدم GitHub Actions لبناء APK على خوادم GitHub.

## الخطوات من Android

1. أنشئ حساب GitHub إذا ما عندك.
2. أنشئ Repository جديد، مثلاً:
   `ZaiTalk`
3. ارفع **محتويات** هذا المشروع إلى المستودع، وليس ملف ZIP داخله فقط.
4. افتح تبويب `Actions`.
5. اختر:
   `ZaiTalk Android Build`
6. اضغط:
   `Run workflow`.
7. انتظر انتهاء البناء.
8. افتح نتيجة الـworkflow.
9. من قسم `Artifacts` نزّل:
   `ZaiTalk-debug-apk`
10. فك ملف الـartifact إذا كان مضغوطاً، ثم ثبّت APK على هاتفك.

## مهم
هذه الـWorkflow تبني Debug APK للتجربة. قبل Google Play نحتاج Release AAB
مع signing مناسب.

إذا ظهر خطأ في Actions:
- افتح الـworkflow.
- افتح خطوة `Build debug APK`.
- انسخ أول وآخر جزء من رسالة الخطأ وأرسله هنا.

لا ترفع:
- service_role
- Firebase service-account private key
- keystore
- كلمات مرور التوقيع
