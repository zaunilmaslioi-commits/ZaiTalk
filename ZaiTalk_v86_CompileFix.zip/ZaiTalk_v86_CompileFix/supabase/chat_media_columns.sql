-- ZaiTalk v29
alter table public.messages add column if not exists media_url text;
alter table public.messages add column if not exists media_type text;

create index if not exists idx_messages_media
on public.messages(conversation_id, media_type);
