-- ZaiTalk v17: profile fields
alter table public.profiles add column if not exists bio text default '';
alter table public.profiles add column if not exists avatar_url text default '';
create unique index if not exists profiles_username_unique_idx on public.profiles(username);
