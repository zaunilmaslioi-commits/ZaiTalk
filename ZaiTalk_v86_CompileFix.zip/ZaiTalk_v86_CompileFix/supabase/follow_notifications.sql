-- ZaiTalk v42: accepted follow + notifications

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,
  body text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.notifications enable row level security;

drop policy if exists "notifications_insert" on public.notifications;
create policy "notifications_insert" on public.notifications
for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "notifications_select_own" on public.notifications;
create policy "notifications_select_own" on public.notifications
for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "notifications_update_own" on public.notifications;
create policy "notifications_update_own" on public.notifications
for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create index if not exists idx_notifications_user
on public.notifications(user_id,is_read,created_at desc);

-- Prevent duplicate follow rows
create unique index if not exists follows_unique_pair
on public.follows(follower_id,following_id);
