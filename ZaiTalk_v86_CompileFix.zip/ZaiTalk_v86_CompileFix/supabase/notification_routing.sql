-- ZaiTalk v45 — notification routing metadata

alter table public.notifications
add column if not exists reference_id text;

create index if not exists idx_notifications_reference
on public.notifications(reference_id);

-- Recommended event types:
-- follow_request
-- follow_accepted
-- follow_rejected
-- message
-- comment
-- like
