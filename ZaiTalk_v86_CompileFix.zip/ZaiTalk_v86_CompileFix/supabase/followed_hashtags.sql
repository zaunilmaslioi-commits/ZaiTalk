-- ZaiTalk v63 — Followed Hashtags

create table if not exists public.followed_hashtags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tag text not null,
  created_at timestamptz not null default now(),
  unique(user_id, tag)
);

create index if not exists idx_followed_hashtags_user
on public.followed_hashtags(user_id);

create index if not exists idx_followed_hashtags_tag
on public.followed_hashtags(tag);

alter table public.followed_hashtags enable row level security;

drop policy if exists "followed_hashtags_select_own"
on public.followed_hashtags;
create policy "followed_hashtags_select_own"
on public.followed_hashtags for select
to authenticated using (user_id = auth.uid());

drop policy if exists "followed_hashtags_insert_own"
on public.followed_hashtags;
create policy "followed_hashtags_insert_own"
on public.followed_hashtags for insert
to authenticated with check (user_id = auth.uid());

drop policy if exists "followed_hashtags_delete_own"
on public.followed_hashtags;
create policy "followed_hashtags_delete_own"
on public.followed_hashtags for delete
to authenticated using (user_id = auth.uid());

-- Notification architecture:
-- When a post gets hashtag #example, a trusted server-side trigger/function
-- should notify users following "example". Keep push credentials server-side.
