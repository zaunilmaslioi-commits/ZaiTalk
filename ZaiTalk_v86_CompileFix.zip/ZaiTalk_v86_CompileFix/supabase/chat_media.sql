-- ZaiTalk v28 Chat Media
-- Create a public bucket named chat-media in Supabase Storage.
insert into storage.buckets (id, name, public)
values ('chat-media','chat-media',true)
on conflict (id) do nothing;

-- Users can upload objects into their own folder.
create policy "chat media upload"
on storage.objects for insert to authenticated
with check (bucket_id='chat-media');

create policy "chat media read"
on storage.objects for select to public
using (bucket_id='chat-media');
