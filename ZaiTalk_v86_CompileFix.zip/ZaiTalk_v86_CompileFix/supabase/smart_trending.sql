-- ZaiTalk v60 — Smart Trending

-- Recommended counters on posts.
alter table public.posts
  add column if not exists views bigint not null default 0;

alter table public.posts
  add column if not exists likes_count bigint not null default 0;

alter table public.posts
  add column if not exists comments_count bigint not null default 0;

create index if not exists idx_posts_trending_time
on public.posts(created_at desc);

create index if not exists idx_posts_trending_likes
on public.posts(likes_count desc);

create index if not exists idx_posts_trending_comments
on public.posts(comments_count desc);

-- Suggested score:
-- likes × 3 + comments × 5 + views × 0.25
-- This can later be moved to a database function for scale.
