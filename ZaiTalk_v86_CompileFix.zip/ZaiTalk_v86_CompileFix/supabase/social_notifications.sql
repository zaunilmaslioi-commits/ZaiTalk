-- ZaiTalk v46 — social notification metadata

alter table public.notifications
add column if not exists reference_id text;

create index if not exists idx_notifications_type
on public.notifications(user_id,type,created_at desc);

create index if not exists idx_notifications_reference_type
on public.notifications(reference_id,type);

-- Suggested event types:
-- like
-- comment
-- follow_request
-- follow_accepted
-- follow_rejected
-- message
