-- ZaiTalk v59 — Hashtags & Trending

-- Optional generated hashtag table for production-scale trending.
create table if not exists public.hashtags (
  id uuid primary key default gen_random_uuid(),
  tag text not null unique,
  use_count bigint not null default 0,
  updated_at timestamptz not null default now()
);

alter table public.hashtags enable row level security;

drop policy if exists "hashtags_public_read" on public.hashtags;
create policy "hashtags_public_read" on public.hashtags
for select to authenticated
using (true);

create index if not exists idx_hashtags_trending
on public.hashtags(use_count desc,updated_at desc);

-- Current v59 can derive hashtags directly from posts.
-- For large datasets, populate hashtags through a trusted server trigger.
