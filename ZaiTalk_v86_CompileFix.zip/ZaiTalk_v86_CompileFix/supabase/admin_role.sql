-- ZaiTalk v38 — secure admin role
alter table public.profiles
add column if not exists role text not null default 'user';

create index if not exists idx_profiles_role on public.profiles(role);

-- IMPORTANT:
-- Set the first administrator manually from a trusted SQL session:
-- update public.profiles set role='admin' where id='YOUR_USER_UUID';

-- Secure report access using a SECURITY DEFINER helper.
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path=public
stable
as $$
  select exists(
    select 1 from public.profiles
    where id=auth.uid() and role='admin'
  );
$$;

drop policy if exists "reports_admin_select" on public.reports;
create policy "reports_admin_select" on public.reports
for select to authenticated
using (auth.uid() = reporter_id or public.is_admin());

drop policy if exists "reports_admin_update" on public.reports;
create policy "reports_admin_update" on public.reports
for update to authenticated
using (public.is_admin())
with check (public.is_admin());
