-- ZaiTalk v25 Realtime
-- Run in Supabase SQL Editor.

-- Enable realtime publication for social tables.
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.likes;
alter publication supabase_realtime add table public.comments;

-- Useful indexes
create index if not exists idx_messages_conversation_created
on public.messages(conversation_id, created_at desc);

create index if not exists idx_notifications_user_created
on public.notifications(user_id, created_at desc);

create index if not exists idx_comments_post_created
on public.comments(post_id, created_at desc);

-- Recommended: enable replica identity for complete update/delete payloads.
alter table public.messages replica identity full;
alter table public.notifications replica identity full;
alter table public.likes replica identity full;
alter table public.comments replica identity full;
