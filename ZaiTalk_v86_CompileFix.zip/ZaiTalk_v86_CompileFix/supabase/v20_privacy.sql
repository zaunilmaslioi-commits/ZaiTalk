-- ZaiTalk v20: privacy, blocking and reports
create table if not exists public.blocks (
 id uuid primary key default gen_random_uuid(),
 blocker_id uuid not null references auth.users(id) on delete cascade,
 blocked_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(),
 unique(blocker_id,blocked_id)
);

create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references auth.users(id) on delete cascade,
 reported_user_id uuid references auth.users(id) on delete set null,
 post_id uuid references public.posts(id) on delete set null,
 reason text not null,
 created_at timestamptz not null default now()
);

alter table public.blocks enable row level security;
alter table public.reports enable row level security;

create policy "blocks own read" on public.blocks for select to authenticated using (blocker_id=auth.uid());
create policy "blocks own insert" on public.blocks for insert to authenticated with check (blocker_id=auth.uid());
create policy "blocks own delete" on public.blocks for delete to authenticated using (blocker_id=auth.uid());

create policy "reports own insert" on public.reports for insert to authenticated with check (reporter_id=auth.uid());

create index if not exists blocks_blocker_idx on public.blocks(blocker_id);
create index if not exists reports_reporter_idx on public.reports(reporter_id);
