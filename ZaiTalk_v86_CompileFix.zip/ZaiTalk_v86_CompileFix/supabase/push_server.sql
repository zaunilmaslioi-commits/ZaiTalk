-- ZaiTalk v48 — push server support

create index if not exists idx_device_tokens_lookup
on public.device_tokens(user_id, platform);

-- Optional cleanup helper:
-- Remove a token when Firebase reports it as invalid.
-- Do this from a trusted backend, not directly from an untrusted client.
