-- ZaiTalk v36 — Secure blocking with RLS
-- Run after block_system.sql

-- Helper: whether two users have a blocking relationship.
create or replace function public.is_blocked_between(a uuid, b uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists(
    select 1 from public.blocks
    where (blocker_id=a and blocked_id=b)
       or (blocker_id=b and blocked_id=a)
  );
$$;

-- Messages: block both directions.
drop policy if exists "messages_insert_no_block" on public.messages;
create policy "messages_insert_no_block" on public.messages
for insert to authenticated
with check (
  auth.uid() = sender_id
  and not public.is_blocked_between(
    auth.uid(),
    (select cm.user_id
       from public.conversation_members cm
       where cm.conversation_id = conversation_id
         and cm.user_id <> auth.uid()
       limit 1)
  )
);

-- Likes: blocked users cannot like each other's posts.
drop policy if exists "likes_insert_no_block" on public.likes;
create policy "likes_insert_no_block" on public.likes
for insert to authenticated
with check (
  auth.uid() = user_id
  and not public.is_blocked_between(
    auth.uid(),
    (select p.user_id from public.posts p where p.id = post_id)
  )
);

-- Comments: blocked users cannot comment on each other's posts.
drop policy if exists "comments_insert_no_block" on public.comments;
create policy "comments_insert_no_block" on public.comments
for insert to authenticated
with check (
  auth.uid() = user_id
  and not public.is_blocked_between(
    auth.uid(),
    (select p.user_id from public.posts p where p.id = post_id)
  )
);

-- Follows: blocked users cannot follow each other.
drop policy if exists "follows_insert_no_block" on public.follows;
create policy "follows_insert_no_block" on public.follows
for insert to authenticated
with check (
  auth.uid() = follower_id
  and not public.is_blocked_between(follower_id, following_id)
);

create index if not exists idx_blocks_pair
on public.blocks(blocker_id, blocked_id);
