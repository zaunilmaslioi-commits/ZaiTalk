-- ZaiTalk v15 interaction indexes
create index if not exists likes_user_post_idx on public.likes(user_id,post_id);
create index if not exists comments_created_idx on public.comments(post_id,created_at desc);
create unique index if not exists likes_unique_idx on public.likes(user_id,post_id);
