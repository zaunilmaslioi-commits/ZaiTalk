-- ZaiTalk v32: read receipts + presence

alter table public.messages add column if not exists status text default 'sent';
alter table public.messages add column if not exists read_at timestamptz;

alter table public.profiles add column if not exists last_seen timestamptz;
alter table public.profiles add column if not exists is_online boolean default false;

create index if not exists idx_messages_status
on public.messages(conversation_id, status);

create index if not exists idx_profiles_presence
on public.profiles(is_online, last_seen);

-- Optional Realtime support
alter publication supabase_realtime add table public.profiles;
