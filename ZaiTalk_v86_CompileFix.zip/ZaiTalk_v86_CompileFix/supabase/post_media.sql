-- ZaiTalk v53 — post media

alter table public.posts
add column if not exists media_url text;

alter table public.posts
add column if not exists media_type text
check (media_type is null or media_type in ('image','video'));

create index if not exists idx_posts_media
on public.posts(media_type,created_at desc);

-- Create a Storage bucket named:
-- post-media
--
-- Recommended production Storage policies:
-- authenticated users may upload only under their own user-id folder.
-- public read may be enabled if posts are public.
-- private accounts should use signed URLs or protected Storage policies.
