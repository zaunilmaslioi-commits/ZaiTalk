-- ZaiTalk v58 — Explore/Search indexes

create index if not exists idx_profiles_username
on public.profiles(username);

create index if not exists idx_profiles_display_name
on public.profiles(display_name);

create index if not exists idx_posts_content
on public.posts using gin (to_tsvector('simple', coalesce(content,'')));

create index if not exists idx_posts_explore
on public.posts(created_at desc);
