-- ZaiTalk v13: profile/reels support
alter table public.posts add column if not exists media_url text;
alter table public.posts add column if not exists media_type text;

create index if not exists posts_media_idx on public.posts(media_type,created_at desc);

-- Optional counters can be calculated from follows/likes instead of stored columns.
