-- ZaiTalk v62 — Explore Pro

create index if not exists idx_posts_content_lower
on public.posts(lower(content));

create index if not exists idx_profiles_username_lower
on public.profiles(lower(username));

create index if not exists idx_profiles_display_name_lower
on public.profiles(lower(display_name));

-- Hashtag tables from v59 remain compatible.
-- For production search, migrate hashtag extraction to post_hashtags
-- and query the junction table instead of scanning post text.
