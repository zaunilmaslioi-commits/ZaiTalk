-- ZaiTalk v34: synced privacy
alter table public.profiles add column if not exists privacy_show_last_seen boolean default true;
alter table public.profiles add column if not exists privacy_show_online boolean default true;
alter table public.profiles add column if not exists privacy_read_receipts boolean default true;

-- Users should be able to update only their own profile.
-- Keep your existing profiles RLS policies from previous versions.
create index if not exists idx_profiles_privacy_sync
on public.profiles(id);
