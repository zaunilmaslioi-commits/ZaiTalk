-- ZaiTalk v33 privacy
-- Privacy preferences are stored locally per device in this version.
-- These columns are available if you later want server-side sync.

alter table public.profiles add column if not exists privacy_show_last_seen boolean default true;
alter table public.profiles add column if not exists privacy_show_online boolean default true;
alter table public.profiles add column if not exists privacy_read_receipts boolean default true;

create index if not exists idx_profiles_privacy
on public.profiles(id, privacy_show_last_seen, privacy_show_online);
