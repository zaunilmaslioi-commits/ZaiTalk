-- ZaiTalk v37 — Reports and moderation
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('user','post')),
  target_user_id uuid references public.profiles(id) on delete cascade,
  target_post_id uuid references public.posts(id) on delete cascade,
  reason text not null,
  status text not null default 'pending'
    check (status in ('pending','reviewed','resolved','dismissed')),
  moderator_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

alter table public.reports enable row level security;

drop policy if exists "reports_insert_own" on public.reports;
create policy "reports_insert_own" on public.reports
for insert to authenticated
with check (auth.uid() = reporter_id);

drop policy if exists "reports_select_own" on public.reports;
create policy "reports_select_own" on public.reports
for select to authenticated
using (auth.uid() = reporter_id);

create index if not exists idx_reports_status_created
on public.reports(status, created_at desc);

create index if not exists idx_reports_target_user
on public.reports(target_user_id);

create index if not exists idx_reports_target_post
on public.reports(target_post_id);

-- IMPORTANT:
-- Moderator/admin policies should be added only after defining a secure admin role.
-- Do not expose all reports to normal authenticated users.
