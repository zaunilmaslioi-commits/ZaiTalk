-- ZaiTalk v44 — Realtime notifications
-- Enable realtime publication for notifications.
-- Run this after creating the notifications table.

alter table public.notifications replica identity full;

do $$
begin
  begin
    alter publication supabase_realtime add table public.notifications;
  exception when duplicate_object then
    null;
  end;
end $$;

create index if not exists idx_notifications_realtime
on public.notifications(user_id,created_at desc);
