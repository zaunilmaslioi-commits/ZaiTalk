-- ZaiTalk v52 — Home feed saves

create table if not exists public.saves (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

alter table public.saves enable row level security;

drop policy if exists "saves_insert_own" on public.saves;
create policy "saves_insert_own" on public.saves
for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "saves_select_own" on public.saves;
create policy "saves_select_own" on public.saves
for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "saves_delete_own" on public.saves;
create policy "saves_delete_own" on public.saves
for delete to authenticated
using (auth.uid() = user_id);

create index if not exists idx_saves_user
on public.saves(user_id,created_at desc);

create index if not exists idx_posts_created
on public.posts(created_at desc);
