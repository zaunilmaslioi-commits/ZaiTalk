-- ZaiTalk v40 — account verification

alter table public.profiles
add column if not exists is_verified boolean not null default false;

create table if not exists public.verification_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  note text,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

alter table public.verification_requests enable row level security;

drop policy if exists "verification_insert_own" on public.verification_requests;
create policy "verification_insert_own" on public.verification_requests
for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "verification_select_own" on public.verification_requests;
create policy "verification_select_own" on public.verification_requests
for select to authenticated
using (auth.uid() = user_id or public.is_admin());

drop policy if exists "verification_admin_update" on public.verification_requests;
create policy "verification_admin_update" on public.verification_requests
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "profiles_admin_verify" on public.profiles;
create policy "profiles_admin_verify" on public.profiles
for update to authenticated
using (auth.uid() = id or public.is_admin())
with check (auth.uid() = id or public.is_admin());

create index if not exists idx_verification_status
on public.verification_requests(status, created_at desc);

create index if not exists idx_profiles_verified
on public.profiles(is_verified);
