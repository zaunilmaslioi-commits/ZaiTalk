-- ZaiTalk v41 — private accounts and follow requests

alter table public.profiles
add column if not exists is_private boolean not null default false;

create table if not exists public.follow_requests (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique(follower_id, following_id)
);

alter table public.follow_requests enable row level security;

drop policy if exists "follow_request_insert" on public.follow_requests;
create policy "follow_request_insert" on public.follow_requests
for insert to authenticated
with check (auth.uid() = follower_id);

drop policy if exists "follow_request_select" on public.follow_requests;
create policy "follow_request_select" on public.follow_requests
for select to authenticated
using (auth.uid() = follower_id or auth.uid() = following_id);

drop policy if exists "follow_request_update_owner" on public.follow_requests;
create policy "follow_request_update_owner" on public.follow_requests
for update to authenticated
using (auth.uid() = following_id)
with check (auth.uid() = following_id);

create index if not exists idx_follow_requests_target
on public.follow_requests(following_id,status,created_at desc);

create index if not exists idx_profiles_private
on public.profiles(is_private);
