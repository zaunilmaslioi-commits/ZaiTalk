// ZaiTalk v49 — message push bridge
// Deploy this as a protected Supabase Edge Function.
// The database trigger/webhook should call it after a new message is created.
//
// Never put Firebase service-account credentials in Android.
// Keep credentials in server-side secrets.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({error:"POST required"}), {
      status:405, headers:{"content-type":"application/json"}
    });
  }

  const event = await req.json().catch(() => ({}));
  const record = event.record || event;

  const receiverId = record.receiver_id || record.recipient_id || "";
  const messageId = record.id || "";
  const text = record.body || record.content || "لديك رسالة جديدة";

  if (!receiverId) {
    return new Response(JSON.stringify({ok:false,error:"receiver_id missing"}), {
      status:400, headers:{"content-type":"application/json"}
    });
  }

  // Server-side lookup. The actual Firebase send should be performed
  // through a trusted Firebase Admin service or secure push provider.
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const {data: tokens, error} = await supabase
    .from("device_tokens")
    .select("token")
    .eq("user_id", receiverId)
    .eq("platform","android");

  if (error) {
    return new Response(JSON.stringify({ok:false,error:"token_lookup_failed"}), {
      status:500, headers:{"content-type":"application/json"}
    });
  }

  // The Firebase Admin send is intentionally delegated to the secure
  // server layer. No Admin key is exposed here or to Android.
  return new Response(JSON.stringify({
    ok:true,
    queued:true,
    message_id:messageId,
    token_count:(tokens || []).length,
    preview:text.slice(0,80)
  }), {
    headers:{"content-type":"application/json"}
  });
});
