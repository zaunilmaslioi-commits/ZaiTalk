// ZaiTalk v64 — server-side hashtag notification blueprint
// Deploy as a Supabase Edge Function.
// Keep Firebase/Supabase service credentials in server secrets only.
//
// Flow:
// 1) Receive post_id + author_id + hashtag.
// 2) Query followed_hashtags for matching tag.
// 3) Create notifications rows for those users.
// 4) Optionally call the push provider using server-side secrets.
//
// Never put Firebase service-account JSON or Supabase service_role
// keys inside the Android application.

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("POST required", { status: 405 });
  }

  const body = await req.json().catch(() => ({}));
  if (!body.tag || !body.post_id) {
    return Response.json({error:"tag and post_id are required"}, {status:400});
  }

  // Connect your Supabase admin client here using environment secrets.
  // Then insert notifications for matching followed_hashtags users.
  return Response.json({
    ok:true,
    mode:"blueprint",
    tag:String(body.tag),
    post_id:String(body.post_id)
  });
});
