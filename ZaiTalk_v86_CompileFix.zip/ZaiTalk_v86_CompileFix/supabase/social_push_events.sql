-- ZaiTalk v50 — social Push event preparation
--
-- Recommended production flow:
-- likes INSERT       -> social event handler -> FCM
-- comments INSERT    -> social event handler -> FCM
-- follows INSERT     -> social event handler -> FCM
-- follow_requests    -> social event handler -> FCM
-- messages INSERT    -> message handler       -> FCM
--
-- The handlers should:
-- 1. authenticate/validate the database event
-- 2. resolve the target user's device_tokens
-- 3. send through Firebase Admin
-- 4. remove invalid FCM tokens when Firebase rejects them

create index if not exists idx_likes_post
on public.likes(post_id);

create index if not exists idx_comments_post
on public.comments(post_id);

create index if not exists idx_follows_following
on public.follows(following_id);

create index if not exists idx_follow_requests_following
on public.follow_requests(following_id,status);
