-- ZaiTalk v61 — Trending Now

-- Keep counters indexed for fast ranking.
create index if not exists idx_posts_likes_count
on public.posts(likes_count desc);

create index if not exists idx_posts_views_count
on public.posts(views desc);

create index if not exists idx_posts_comments_count
on public.posts(comments_count desc);

create index if not exists idx_posts_created_at_desc
on public.posts(created_at desc);

-- Client freshness model:
-- freshness = 1 / (1 + age_hours / 12)^0.75
-- trend = (likes*3 + comments*5 + views*0.25) * freshness
--
-- For production scale, move this formula to PostgreSQL/RPC
-- and use server-side counters/triggers.
