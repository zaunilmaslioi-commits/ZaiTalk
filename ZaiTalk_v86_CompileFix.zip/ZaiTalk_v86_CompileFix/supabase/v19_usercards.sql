-- ZaiTalk v19 user card support
create index if not exists profiles_avatar_idx on public.profiles(id,avatar_url);
create index if not exists profiles_bio_idx on public.profiles(id);
