-- ZaiTalk v49 — message push trigger preparation
--
-- Recommended production flow:
-- messages INSERT
--      ↓
-- Supabase Database Webhook / Edge Function
--      ↓
-- secure server push service
--      ↓
-- Firebase Cloud Messaging
--
-- Add an index for recipient lookups.

create index if not exists idx_messages_receiver_created
on public.messages(receiver_id, created_at desc);

create index if not exists idx_device_tokens_receiver
on public.device_tokens(user_id, platform);
