-- ZaiTalk v43 — notifications center
-- v42 already creates the notifications table and RLS.
-- This migration adds indexes useful for the notification center.

create index if not exists idx_notifications_unread
on public.notifications(user_id, is_read, created_at desc);

create index if not exists idx_notifications_created
on public.notifications(user_id, created_at desc);
