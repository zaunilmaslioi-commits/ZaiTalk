-- ZaiTalk v31
-- Audio uses the existing chat-media bucket.
alter table public.messages add column if not exists media_type text;
alter table public.messages add column if not exists media_url text;
