-- ZaiTalk v39 — Admin management security

-- Admin-only profile role changes.
drop policy if exists "profiles_admin_role_update" on public.profiles;
create policy "profiles_admin_role_update" on public.profiles
for update to authenticated
using (auth.uid() = id or public.is_admin())
with check (
  auth.uid() = id
  or public.is_admin()
);

-- Admin-only post deletion/update.
drop policy if exists "posts_admin_delete" on public.posts;
create policy "posts_admin_delete" on public.posts
for delete to authenticated
using (auth.uid() = user_id or public.is_admin());

drop policy if exists "posts_admin_update" on public.posts;
create policy "posts_admin_update" on public.posts
for update to authenticated
using (auth.uid() = user_id or public.is_admin())
with check (auth.uid() = user_id or public.is_admin());

create index if not exists idx_profiles_role_created
on public.profiles(role, created_at desc);

create index if not exists idx_posts_created
on public.posts(created_at desc);
