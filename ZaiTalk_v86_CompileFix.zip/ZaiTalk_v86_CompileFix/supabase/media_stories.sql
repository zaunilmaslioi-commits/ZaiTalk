-- ZaiTalk v11: stories + notifications + media columns
create table if not exists public.stories (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 media_url text not null,
 media_type text not null default 'image',
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours')
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null,
 type text not null,
 post_id uuid references public.posts(id) on delete cascade,
 created_at timestamptz not null default now(),
 read boolean not null default false
);
create index if not exists stories_expires_idx on public.stories(expires_at desc);
create index if not exists notifications_user_idx on public.notifications(user_id,created_at desc);
alter table public.stories enable row level security;
alter table public.notifications enable row level security;

create policy "stories read" on public.stories for select to authenticated using (expires_at > now());
create policy "stories insert own" on public.stories for insert to authenticated with check (user_id = auth.uid());
create policy "stories delete own" on public.stories for delete to authenticated using (user_id = auth.uid());

create policy "notifications own read" on public.notifications for select to authenticated using (user_id = auth.uid());
create policy "notifications own update" on public.notifications for update to authenticated using (user_id = auth.uid());
create policy "notifications insert" on public.notifications for insert to authenticated with check (actor_id = auth.uid());
