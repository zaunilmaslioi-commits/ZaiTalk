-- ZaiTalk v12: chat + notification helpers
create index if not exists conversations_updated_idx on public.conversations(updated_at desc);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id);
create index if not exists messages_created_idx on public.messages(conversation_id,created_at);

alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

create policy if not exists "conversation members read own"
on public.conversation_members for select to authenticated
using (user_id = auth.uid());

create policy if not exists "messages read by members"
on public.messages for select to authenticated
using (
 exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = messages.conversation_id
  and cm.user_id = auth.uid()
 )
);

create policy if not exists "messages insert by sender"
on public.messages for insert to authenticated
with check (
 sender_id = auth.uid() and
 exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = messages.conversation_id
  and cm.user_id = auth.uid()
 )
);

-- Enable Realtime for messages when available in your Supabase project.
-- In Supabase Dashboard: Database -> Publications -> supabase_realtime -> add messages.
