-- ZaiTalk v10: social feature indexes/policies.
-- Run after the main v8 schema.
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists likes_post_idx on public.likes(post_id);
create index if not exists comments_post_idx on public.comments(post_id);
create index if not exists follows_follower_idx on public.follows(follower_id);
create index if not exists follows_following_idx on public.follows(following_id);
create index if not exists messages_conversation_idx on public.messages(conversation_id,created_at);
