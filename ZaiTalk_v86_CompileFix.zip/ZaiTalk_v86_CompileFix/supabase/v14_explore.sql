-- ZaiTalk v14: explore/search indexes
create index if not exists profiles_username_idx on public.profiles(username);
create index if not exists posts_user_created_idx on public.posts(user_id,created_at desc);

-- If your profiles table uses display_name, add a text index as needed.
