-- ZaiTalk v64 Final Release
-- Run this after the previous v59-v63 SQL files.

create table if not exists public.followed_hashtags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tag text not null,
  created_at timestamptz not null default now(),
  unique(user_id, tag)
);

create index if not exists idx_followed_hashtags_user
on public.followed_hashtags(user_id);

create index if not exists idx_followed_hashtags_tag
on public.followed_hashtags(tag);

alter table public.followed_hashtags enable row level security;

drop policy if exists "followed_hashtags_select_own" on public.followed_hashtags;
create policy "followed_hashtags_select_own"
on public.followed_hashtags for select to authenticated
using (user_id = auth.uid());

drop policy if exists "followed_hashtags_insert_own" on public.followed_hashtags;
create policy "followed_hashtags_insert_own"
on public.followed_hashtags for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists "followed_hashtags_delete_own" on public.followed_hashtags;
create policy "followed_hashtags_delete_own"
on public.followed_hashtags for delete to authenticated
using (user_id = auth.uid());

-- Counters used by Trending.
alter table public.posts add column if not exists views bigint not null default 0;
alter table public.posts add column if not exists likes_count bigint not null default 0;
alter table public.posts add column if not exists comments_count bigint not null default 0;

create index if not exists idx_posts_created_at_desc on public.posts(created_at desc);
create index if not exists idx_posts_likes_count on public.posts(likes_count desc);
create index if not exists idx_posts_views_count on public.posts(views desc);
create index if not exists idx_posts_comments_count on public.posts(comments_count desc);
