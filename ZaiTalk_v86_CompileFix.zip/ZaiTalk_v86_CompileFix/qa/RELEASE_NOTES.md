# ZaiTalk v66

QA and Release Hardening.

- Added complete smoke-test checklist.
- Added production known-limits checklist.
- Kept all previous ZaiTalk features.
- No service-role or Firebase server secrets included.
- Release remains a production candidate until physical-device testing and signed AAB build pass.
