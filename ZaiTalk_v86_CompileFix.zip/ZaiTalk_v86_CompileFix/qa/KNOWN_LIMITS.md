# Known limits before public launch

1. A real Firebase project and `google-services.json` are required for production push.
2. Server-side push needs deployed Edge Functions/backend secrets.
3. Storage buckets and Storage RLS must be configured in the real Supabase project.
4. Database migrations from earlier ZaiTalk versions must exist.
5. Release signing must be configured outside the source archive.
6. Android release builds should be tested on a physical device.
7. Trending counters should eventually be maintained server-side for scale.
8. Rate limiting and abuse protection should be enabled before a public launch.
