# ZaiTalk v66 — Smoke Test

## 1. Account
- Sign up with a test email.
- Confirm email.
- Log in.
- Log out.
- Request password reset.
- Set a new password.

## 2. Social
- Create text post.
- Upload image post.
- Upload video post.
- Like/unlike.
- Add/delete comment.
- Save/unsave.
- Share.
- Open profile.

## 3. Explore
- Search user.
- Search post.
- Open hashtag.
- Follow/unfollow hashtag.
- Open trending.
- Check most liked/viewed/engaged sections.

## 4. Reels
- Open Reels.
- Play/pause.
- Scroll between videos.
- Like/comment/share/save.
- Verify off-screen playback stops.

## 5. Chat
- Send text.
- Send image/video.
- Record/send voice.
- Verify delivered/read state.
- Verify online/last-seen privacy.

## 6. Safety
- Block/unblock.
- Report user.
- Report post.
- Private account follow request.
- Approve/reject request.

## 7. Notifications
- Follow notification.
- Like/comment notification.
- Message notification.
- Follow-request notification.
- Mark notification as read.
- Verify realtime/push configuration.

## 8. Admin
- Admin login.
- Review reports.
- Review verification requests.
- Manage moderation actions.

## 9. Release
- Build release APK/AAB.
- Install release build on a physical device.
- Test on Android 13+.
- Test offline/poor-network behavior.
- Confirm no secrets are inside the APK.
