# v72 Build Compatibility

راجعت طبقة SupabaseClient مقابل الوحدات القديمة والجديدة.

الإصلاح:
- توفير API static متوافق مع الوحدات القديمة (`select/insert/patch/delete`).
- توفير API instance للموديولات التي تحتاج Session token (`selectAuth/insertAuth/...`).
- الإبقاء على Auth وStorage.
- تعديل HashtagFollow وFollowedHashtags لاستخدام API المصادق عليه.

هذا يمنع تعارض static/instance في Java الذي كان سيوقف الـCompile.
