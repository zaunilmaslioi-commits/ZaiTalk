# ZaiTalk Push Event Specification

| type | trigger | reference_id | notification |
|---|---|---|---|
| message | new message | message.id | لديك رسالة جديدة |
| like | post liked | post.id | أعجب شخص بمنشورك |
| comment | comment created | post.id | تم التعليق على منشورك |
| follow_request | follow request | requester.id | لديك طلب متابعة |
| follow_accepted | request accepted | accepter.id | تم قبول طلب المتابعة |

ملاحظات:
- لا ترسل إشعاراً لنفس صاحب الحدث.
- احترم الحظر والخصوصية.
- لا ترسل Push لمستخدم لا يملك token صالحاً.
- عند Firebase error غير صالح، احذف token من device_tokens.
