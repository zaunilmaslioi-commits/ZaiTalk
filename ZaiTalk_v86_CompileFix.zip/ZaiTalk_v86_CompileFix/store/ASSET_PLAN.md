# Google Play Visual Assets

جهّز من التصميم النهائي:

1. App icon — أيقونة التطبيق.
2. Feature graphic — صورة Google Play الرئيسية.
3. Screenshot 1 — الصفحة الرئيسية.
4. Screenshot 2 — Explore.
5. Screenshot 3 — Reels.
6. Screenshot 4 — Chat.
7. Screenshot 5 — Profile.
8. Screenshot 6 — Trending/Hashtags.

يفضل أن تكون لقطات الشاشة من النسخة Release الحقيقية، وليس Mockups غير مطابقة للتطبيق.
