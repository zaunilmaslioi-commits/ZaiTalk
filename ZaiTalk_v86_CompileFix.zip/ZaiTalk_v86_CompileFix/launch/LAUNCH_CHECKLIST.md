# ZaiTalk 1.0 Launch Checklist

## Build
- [ ] Gradle sync passes
- [ ] Debug build passes
- [ ] Release build passes
- [ ] Signed AAB generated
- [ ] Version code/version name correct

## Backend
- [ ] Supabase RLS reviewed
- [ ] Storage policies reviewed
- [ ] Realtime configured
- [ ] Edge Functions deployed
- [ ] Push server secrets configured

## Testing
- [ ] Login/signup
- [ ] Password reset
- [ ] Posts/media
- [ ] Reels
- [ ] Chat
- [ ] Notifications
- [ ] Explore/hashtags/trending
- [ ] Privacy/block/report
- [ ] Admin/moderation
- [ ] Crash testing
- [ ] Poor network testing

## Store
- [ ] Privacy policy
- [ ] Data Safety
- [ ] Content rating
- [ ] App icon
- [ ] Screenshots
- [ ] Store description
- [ ] Internal test
- [ ] Closed test
- [ ] Production rollout
