# ZaiTalk Data Map — Launch Review

Potential data handled by the app:
- Account email/authentication data
- Profile information
- User-created posts/media
- Comments/likes/saves
- Chat messages and media
- Device push token
- Online/last-seen settings
- Reports and moderation records

Before Google Play submission:
- confirm the actual data collected by the final build;
- update the privacy policy;
- complete Google's Data Safety form accurately;
- request only permissions the app really needs;
- provide account/data deletion flow where required.
