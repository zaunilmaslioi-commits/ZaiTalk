# Analytics / Crash Readiness

Before public launch, choose a crash/analytics provider and configure it
through the provider's official Android SDK.

Recommended events to track:
- app_open
- signup_success
- login_success
- post_created
- reel_viewed
- message_sent
- notification_opened
- report_submitted

Do not log:
- passwords
- access tokens
- refresh tokens
- private messages
- private user data not required for diagnostics.

For crashes, capture stack traces and app version/device information while
respecting the app's privacy policy.
