#!/usr/bin/env bash
set -e
echo "=== ZaiTalk Release Preflight ==="

if [ ! -f "app/src/main/AndroidManifest.xml" ]; then
  echo "ERROR: Android module/Manifest not found"
  exit 1
fi

if grep -RniE 'service_role|firebase.*private|BEGIN PRIVATE KEY' . \
   --exclude-dir=.git --exclude='*.zip' >/dev/null 2>&1; then
  echo "ERROR: possible server secret found in source tree"
  exit 1
fi

if [ ! -f "local.properties" ]; then
  echo "WARNING: local.properties not found; configure Supabase before build"
fi

echo "OK: source preflight passed"
echo "Next: ./gradlew assembleRelease"
echo "Then: ./gradlew bundleRelease"
