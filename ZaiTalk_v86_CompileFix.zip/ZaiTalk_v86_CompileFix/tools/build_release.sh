#!/usr/bin/env bash
set -e
echo "=== ZaiTalk Release Build ==="

if [ ! -x "./gradlew" ]; then
  echo "ERROR: Gradle wrapper not found/executable."
  echo "Open the project in Android Studio and sync Gradle first."
  exit 1
fi

./gradlew clean
./gradlew assembleRelease
./gradlew bundleRelease

echo ""
echo "Release build completed."
echo "Look under app/build/outputs/ for APK/AAB files."
