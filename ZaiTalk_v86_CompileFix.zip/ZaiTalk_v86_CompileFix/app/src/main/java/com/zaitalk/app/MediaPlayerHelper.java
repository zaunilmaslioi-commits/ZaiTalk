package com.zaitalk.app;

import android.content.*;
import android.net.Uri;
import android.widget.*;

public class MediaPlayerHelper {
  public static void playVideo(Context ctx,VideoView video,String url){
    try{
      video.setVideoURI(Uri.parse(url));
      video.setOnPreparedListener(mp->{
        mp.setLooping(true);
        video.start();
      });
      video.setOnCompletionListener(mp->video.start());
    }catch(Exception ignored){}
  }
}