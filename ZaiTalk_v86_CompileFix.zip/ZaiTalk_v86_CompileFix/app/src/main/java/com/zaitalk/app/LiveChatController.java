package com.zaitalk.app;

import org.json.*;

public class LiveChatController {
  private LiveRealtime realtime;
  private final String topic;

  public interface Listener {
    void connected();
    void newMessage(JSONObject row);
    void error(String message);
  }

  public LiveChatController(String topic){this.topic=topic;}

  public void start(String url,String key,String token,Listener listener){
    realtime=new LiveRealtime(url,key,token);
    realtime.connect(topic,new LiveRealtime.Listener(){
      public void onReady(){listener.connected();}
      public void onError(String m){listener.error(m);}
      public void onEvent(String event,String payload){
        if(!"postgres_changes".equals(event)) return;
        try{
          JSONObject p=new JSONObject(payload);
          JSONObject record=p.optJSONObject("data");
          if(record==null) record=p.optJSONObject("record");
          if(record!=null) listener.newMessage(record);
        }catch(Exception e){listener.error(e.getMessage());}
      }
    });
  }
  public void stop(){if(realtime!=null) realtime.close();}
}