package com.zaitalk.app;

import android.content.*;

public class AdminManager {
  private final Context ctx;
  public AdminManager(Context c){ctx=c;}

  public boolean isAdmin(){
    try{
      String uid=SessionStore.getUserId();
      String raw=SupabaseClient.select("profiles?id=eq."+uid+"&select=role");
      org.json.JSONArray a=new org.json.JSONArray(raw);
      return a.length()>0 && "admin".equalsIgnoreCase(a.getJSONObject(0).optString("role"));
    }catch(Exception e){return false;}
  }

  public String reports() throws Exception {
    return SupabaseClient.select("reports?select=*&order=created_at.desc");
  }

  public String users() throws Exception {
    return SupabaseClient.select("profiles?select=id,username,bio,role,created_at&order=created_at.desc");
  }

  public String posts() throws Exception {
    return SupabaseClient.select("posts?select=id,user_id,content,created_at&order=created_at.desc");
  }

  public void setUserRole(String userId,String role){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject(); p.put("role",role);
        SupabaseClient.patch("profiles?id=eq."+userId,p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public void deletePost(String postId){
    new Thread(()->{
      try{ SupabaseClient.delete("posts?id=eq."+postId); }catch(Exception ignored){}
    }).start();
  }

  public void updateReport(String id,String status,String note){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("status",status); p.put("moderator_note",note);
        p.put("reviewed_at",new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",java.util.Locale.US).format(new java.util.Date()));
        SupabaseClient.patch("reports?id=eq."+id,p.toString());
      }catch(Exception ignored){}
    }).start();
  }
}