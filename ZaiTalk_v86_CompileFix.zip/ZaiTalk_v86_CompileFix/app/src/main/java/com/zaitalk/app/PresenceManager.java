package com.zaitalk.app;

import android.content.*;
import java.text.*;
import java.util.*;

public class PresenceManager {
  private final Context ctx;
  public PresenceManager(Context c){ctx=c;}

  public String nowIso(){
    return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US)
      .format(new Date());
  }

  public void setOnline(){
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        if(uid==null||uid.isEmpty())return;
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("last_seen",nowIso());
        p.put("is_online",true);
        SupabaseClient.patch("profiles?id=eq."+uid,p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public void setOffline(){
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        if(uid==null||uid.isEmpty())return;
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("last_seen",nowIso());
        p.put("is_online",false);
        SupabaseClient.patch("profiles?id=eq."+uid,p.toString());
      }catch(Exception ignored){}
    }).start();
  }
}