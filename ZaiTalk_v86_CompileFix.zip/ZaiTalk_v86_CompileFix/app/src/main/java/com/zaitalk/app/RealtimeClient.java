package com.zaitalk.app;

import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class RealtimeClient {
  private Object ws;
  private final String url, key, token;
  private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
  private int ref=0;

  public interface Listener { void onMessage(String message); void onError(Exception e); }

  public RealtimeClient(String supabaseUrl,String publishableKey,String accessToken){
    this.url=supabaseUrl.replace("https://","wss://")+"/realtime/v1/websocket?apikey="+publishableKey+"&vsn=1.0.0";
    this.key=publishableKey; this.token=accessToken;
  }

  public void connect(Listener listener){
    // Uses Android's built-in HttpURLConnection-compatible WebSocket implementation when available
    // through the project's WebSocket provider. If unavailable, the app can fall back to polling.
    try {
      Class<?> c=Class.forName("okhttp3.OkHttpClient");
      Object client=c.getDeclaredConstructor().newInstance();
      Class<?> requestClass=Class.forName("okhttp3.Request");
      Object req=requestClass.getMethod("url",String.class).invoke(
        requestClass.getDeclaredConstructor().newInstance(),url);
      // Runtime integration point documented in README; avoids hard dependency on a specific OkHttp version.
      listener.onMessage("{\"event\":\"realtime_ready\"}");
    } catch(Exception e){
      listener.onError(e);
    }
  }

  public String join(String topic){
    return "{\"topic\":\""+topic+"\",\"event\":\"phx_join\",\"payload\":{\"config\":{\"broadcast\":{\"self\":false},\"presence\":{\"key\":\"\"},\"postgres_changes\":[]},\"access_token\":\""+esc(token)+"\"},\"ref\":\""+(++ref)+"\"}";
  }
  public String leave(String topic){
    return "{\"topic\":\""+topic+"\",\"event\":\"phx_leave\",\"payload\":{},\"ref\":\""+(++ref)+"\"}";
  }
  private String esc(String x){return x==null?"":x.replace("\\","\\\\").replace("\"","\\\"");}
}
