package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.net.Uri;
import java.util.*;
import java.util.regex.*;

public class ResetPasswordActivity extends Activity {
  LinearLayout box; EditText pass1,pass2; String accessToken="", refreshToken="";

  TextView t(String x,int sz){
    TextView v=new TextView(this); v.setText(x); v.setTextColor(Color.WHITE);
    v.setTextSize(sz); v.setPadding(12,12,12,12); return v;
  }
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(24,40,24,24); box.setBackgroundColor(Color.rgb(12,12,16));
    box.addView(t("🔐 إعادة تعيين كلمة المرور",26));
    box.addView(t("أدخل كلمة مرور جديدة لحسابك.",16));
    pass1=new EditText(this); pass1.setHint("كلمة المرور الجديدة"); pass1.setTextColor(Color.WHITE); pass1.setHintTextColor(Color.GRAY); pass1.setInputType(129);
    pass2=new EditText(this); pass2.setHint("تأكيد كلمة المرور"); pass2.setTextColor(Color.WHITE); pass2.setHintTextColor(Color.GRAY); pass2.setInputType(129);
    box.addView(pass1); box.addView(pass2);
    Button save=new Button(this); save.setText("حفظ كلمة المرور"); box.addView(save);
    setContentView(box);
    handle(getIntent());
    save.setOnClickListener(v->save());
  }

  void handle(Intent i){
    Uri u=i.getData();
    if(u==null) return;
    String frag=u.getFragment();
    if(frag!=null){
      for(String p:frag.split("&")){
        String[] kv=p.split("=",2);
        if(kv.length==2){
          if(kv[0].equals("access_token")) accessToken=Uri.decode(kv[1]);
          if(kv[0].equals("refresh_token")) refreshToken=Uri.decode(kv[1]);
        }
      }
    }
    String q=u.getQueryParameter("access_token");
    if(q!=null) accessToken=q;
    if(accessToken.length()>10) toast("تم استلام جلسة الاستعادة. أدخل كلمة المرور الجديدة.");
    else toast("رابط الاستعادة غير صالح أو منتهي.");
  }

  void save(){
    String a=pass1.getText().toString(), b=pass2.getText().toString();
    if(a.length()<6){toast("كلمة المرور يجب أن تكون 6 أحرف على الأقل");return;}
    if(!a.equals(b)){toast("كلمتا المرور غير متطابقتين");return;}
    if(accessToken.length()<10){toast("جلسة الاستعادة غير موجودة.");return;}
    new Thread(()->{
      try{
        SupabaseClient.setPassword(accessToken,a);
        runOnUiThread(()->{
          toast("تم تغيير كلمة المرور بنجاح ✅");
          finish();
        });
      }catch(Exception e){
        runOnUiThread(()->toast("تعذر تغيير كلمة المرور: "+e.getMessage()));
      }
    }).start();
  }
  void toast(String x){Toast.makeText(this,x,Toast.LENGTH_LONG).show();}
}