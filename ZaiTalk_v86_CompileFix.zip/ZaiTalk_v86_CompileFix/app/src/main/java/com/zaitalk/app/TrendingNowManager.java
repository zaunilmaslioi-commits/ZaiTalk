package com.zaitalk.app;

import android.graphics.Color;
import android.widget.*;
import org.json.*;
import java.util.*;

public class TrendingNowManager {
  private final MainActivity a;
  public TrendingNowManager(MainActivity x){a=x;}

  public void load(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?select=id,content,caption,created_at,views,likes_count,comments_count&order=created_at.desc&limit=150");
        JSONArray arr=new JSONArray(raw);
        ArrayList<PostItem> trend=new ArrayList<>();
        ArrayList<PostItem> likes=new ArrayList<>();
        ArrayList<PostItem> views=new ArrayList<>();
        ArrayList<PostItem> engage=new ArrayList<>();

        long now=System.currentTimeMillis();
        for(int i=0;i<arr.length();i++){
          JSONObject p=arr.getJSONObject(i);
          String text=p.optString("content",p.optString("caption",""));
          int l=p.optInt("likes_count",0);
          int c=p.optInt("comments_count",0);
          int v=p.optInt("views",0);
          String created=p.optString("created_at","");
          double age=24;
          try{
            java.text.SimpleDateFormat f=new java.text.SimpleDateFormat(
              "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            long ts=f.parse(created).getTime();
            age=Math.max(1,(now-ts)/3600000.0);
          }catch(Exception ignored){}

          // Freshness decay: newer posts receive more weight.
          double freshness=1.0/Math.pow(1.0+age/12.0,0.75);
          double score=(l*3.0+c*5.0+v*0.25)*freshness;

          PostItem item=new PostItem(text,l,c,v,score);
          trend.add(item); likes.add(item); views.add(item); engage.add(item);
        }

        Collections.sort(trend,(x,y)->Double.compare(y.score,x.score));
        Collections.sort(likes,(x,y)->y.likes-x.likes);
        Collections.sort(views,(x,y)->y.views-x.views);
        Collections.sort(engage,(x,y)->Integer.compare(
          y.likes*3+y.comments*5,x.likes*3+x.comments*5));

        a.runOnUiThread(()->{
          box.removeAllViews();
          section(box,"🔥 ترند الآن",trend,0);
          section(box,"❤️ الأكثر إعجاباً",likes,1);
          section(box,"👁️ الأكثر مشاهدة",views,2);
          section(box,"💬 الأكثر تفاعلاً",engage,3);
        });
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر تحميل الترند",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }

  private void section(LinearLayout box,String title,ArrayList<PostItem> list,int mode){
    TextView h=new TextView(a);
    h.setText(title);
    h.setTextColor(Color.WHITE);
    h.setTextSize(21);
    h.setPadding(8,22,8,10);
    box.addView(h);

    int max=Math.min(5,list.size());
    for(int i=0;i<max;i++){
      PostItem p=list.get(i);
      TextView t=new TextView(a);
      t.setText((i+1)+". "+p.text+
        "\n❤️ "+p.likes+"   💬 "+p.comments+"   👁️ "+p.views+
        (mode==0 ? "\n🔥 Score: "+Math.round(p.score) : ""));
      t.setTextColor(Color.LTGRAY);
      t.setTextSize(15);
      t.setPadding(12,14,12,14);
      box.addView(t);
    }
  }

  static class PostItem{
    String text; int likes,comments,views; double score;
    PostItem(String t,int l,int c,int v,double s){
      text=t;likes=l;comments=c;views=v;score=s;
    }
  }
}