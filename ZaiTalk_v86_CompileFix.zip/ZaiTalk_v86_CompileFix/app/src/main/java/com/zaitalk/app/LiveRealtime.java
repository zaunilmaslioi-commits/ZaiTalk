package com.zaitalk.app;

import okhttp3.*;
import org.json.*;
import java.util.concurrent.TimeUnit;

public class LiveRealtime {
  public interface Listener {
    void onReady();
    void onEvent(String event, String payload);
    void onError(String message);
  }

  private final OkHttpClient client = new OkHttpClient.Builder()
      .readTimeout(0, TimeUnit.MILLISECONDS).build();
  private WebSocket socket;
  private final String wsUrl;
  private final String token;
  private int ref=0;

  public LiveRealtime(String supabaseUrl, String apiKey, String accessToken) {
    wsUrl=supabaseUrl.replace("https://","wss://")
      +"/realtime/v1/websocket?apikey="+apiKey+"&vsn=1.0.0";
    token=accessToken;
  }

  public void connect(String topic, Listener listener) {
    Request req=new Request.Builder().url(wsUrl).build();
    socket=client.newWebSocket(req,new WebSocketListener(){
      @Override public void onOpen(WebSocket ws, Response response){
        try {
          JSONObject p=new JSONObject();
          JSONObject cfg=new JSONObject();
          cfg.put("broadcast",new JSONObject().put("self",false));
          cfg.put("presence",new JSONObject().put("key",""));
          cfg.put("postgres_changes",new JSONArray()
            .put(new JSONObject().put("event","INSERT").put("schema","public")
              .put("table","messages")));
          p.put("config",cfg); p.put("access_token",token);
          send(topic,"phx_join",p);
          listener.onReady();
        } catch(Exception e){listener.onError(e.toString());}
      }

      @Override public void onMessage(WebSocket ws,String text){
        try {
          JSONObject o=new JSONObject(text);
          String event=o.optString("event");
          if("postgres_changes".equals(event) || "presence_diff".equals(event)
              || "broadcast".equals(event) || "phx_reply".equals(event)){
            listener.onEvent(event,o.optString("payload"));
          }
        } catch(Exception e){listener.onError(e.toString());}
      }

      @Override public void onFailure(WebSocket ws,Throwable t,Response r){
        listener.onError(t.getMessage()==null?"Realtime connection failed":t.getMessage());
      }
    });
  }

  public void sendMessageEvent(String topic, JSONObject data){
    try {
      JSONObject p=new JSONObject(); p.put("type","message"); p.put("data",data);
      send(topic,"broadcast",p);
    } catch(Exception ignored) {}
  }

  private void send(String topic,String event,JSONObject payload){
    try {
      JSONObject o=new JSONObject();
      o.put("topic",topic); o.put("event",event); o.put("payload",payload);
      o.put("ref",String.valueOf(++ref));
      if(socket!=null) socket.send(o.toString());
    } catch(Exception ignored){}
  }

  public void close(){if(socket!=null) socket.close(1000,"bye"); client.dispatcher().executorService().shutdown();}
}
