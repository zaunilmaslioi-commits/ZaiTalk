package com.zaitalk.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class SupabaseStorage {
    private final String base = SupabaseConfig.URL.replaceAll("/+$","");
    private final String key = SupabaseConfig.KEY;
    private String token = "";

    public void token(String t){ token=t==null?"":t; }

    public String upload(String bucket, String path, byte[] data, String contentType) throws Exception {
        String safePath = path.replace(" ","_");
        URL u = new URL(base + "/storage/v1/object/" + bucket + "/" + safePath);
        HttpURLConnection c=(HttpURLConnection)u.openConnection();
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setConnectTimeout(15000); c.setReadTimeout(30000);
        c.setRequestProperty("apikey",key);
        c.setRequestProperty("Authorization","Bearer "+(token.isEmpty()?key:token));
        c.setRequestProperty("Content-Type",contentType);
        c.setRequestProperty("x-upsert","true");
        try(OutputStream o=c.getOutputStream()){o.write(data);}
        int code=c.getResponseCode();
        InputStream s=code<400?c.getInputStream():c.getErrorStream();
        StringBuilder b=new StringBuilder();
        if(s!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(s,StandardCharsets.UTF_8))){
            String line; while((line=r.readLine())!=null)b.append(line);
        }
        c.disconnect();
        if(code<200||code>=300) throw new Exception("Storage HTTP "+code+": "+b);
        return base+"/storage/v1/object/public/"+bucket+"/"+safePath;
    }
}
