package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class ExploreActivity extends Activity {
  private ExploreManager manager;
  private LinearLayout users,posts;

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    manager=new ExploreManager((MainActivity)getApplicationContext());

    LinearLayout root=new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(16,16,16,16);
    root.setBackgroundColor(Color.rgb(15,15,18));

    EditText search=new EditText(this);
    search.setHint("🔎 ابحث عن أشخاص أو منشورات");
    search.setTextColor(Color.WHITE);
    search.setHintTextColor(Color.GRAY);

    Button go=new Button(this);
    go.setText("بحث");

    TextView ut=new TextView(this);
    ut.setText("👥 الحسابات");
    ut.setTextColor(Color.WHITE);
    ut.setTextSize(22);

    users=new LinearLayout(this);
    users.setOrientation(LinearLayout.VERTICAL);

    TextView pt=new TextView(this);
    pt.setText("📝 المنشورات");
    pt.setTextColor(Color.WHITE);
    pt.setTextSize(22);

    posts=new LinearLayout(this);
    posts.setOrientation(LinearLayout.VERTICAL);

    ScrollView scroll=new ScrollView(this);
    LinearLayout inside=new LinearLayout(this);
    inside.setOrientation(LinearLayout.VERTICAL);
    inside.addView(ut);
    inside.addView(users);
    inside.addView(pt);
    inside.addView(posts);
    scroll.addView(inside);

    root.addView(search);
    root.addView(go);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    setContentView(root);

    go.setOnClickListener(v->manager.search(
      search.getText().toString(),users,posts));
  }
}