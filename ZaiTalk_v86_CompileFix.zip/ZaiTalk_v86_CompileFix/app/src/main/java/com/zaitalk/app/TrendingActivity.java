package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.widget.*;

public class TrendingActivity extends Activity {
  LinearLayout box;

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    LinearLayout root=new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(18,18,18,18);
    root.setBackgroundColor(Color.rgb(15,15,18));

    TextView title=new TextView(this);
    title.setText("🔥 ZaiTalk — Trending Now");
    title.setTextColor(Color.WHITE);
    title.setTextSize(25);
    title.setPadding(0,0,0,8);

    TextView info=new TextView(this);
    info.setText("الترند يعطي أولوية للمحتوى الجديد والتفاعل القوي");
    info.setTextColor(Color.GRAY);
    info.setTextSize(14);

    box=new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);

    ScrollView scroll=new ScrollView(this);
    scroll.addView(box);

    root.addView(title);
    root.addView(info);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    setContentView(root);
  }
}