package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.widget.*;

public class PostMediaViewerActivity extends Activity {
  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    String type=getIntent().getStringExtra("media_type");
    String url=getIntent().getStringExtra("media_url");

    if("video".equals(type)){
      VideoView v=new VideoView(this);
      v.setBackgroundColor(Color.BLACK);
      setContentView(v);
      MediaPlayerHelper.playVideo(this,v,url);
    }else{
      ImageView i=new ImageView(this);
      i.setBackgroundColor(Color.BLACK);
      i.setScaleType(ImageView.ScaleType.FIT_CENTER);
      // Image URL loading can be connected to Glide/Picasso.
      setContentView(i);
    }
  }
}