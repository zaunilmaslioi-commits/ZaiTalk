package com.zaitalk.app;

import android.content.*;
import android.net.Uri;
import java.io.*;
import java.net.*;

public class ChatMediaUploader {
  public static String upload(Context ctx, Uri uri, String bucket, String objectPath) throws Exception {
    ContentResolver cr=ctx.getContentResolver();
    InputStream in=cr.openInputStream(uri);
    if(in==null) throw new IOException("Cannot open selected file");

    String mime=cr.getType(uri);
    if(mime==null) mime="application/octet-stream";

    String url=SupabaseConfig.URL+"/storage/v1/object/"+bucket+"/"+objectPath;
    HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
    c.setRequestMethod("POST"); c.setDoOutput(true);
    c.setRequestProperty("apikey",SupabaseConfig.KEY);
    c.setRequestProperty("Authorization","Bearer "+SessionStore.getToken());
    c.setRequestProperty("Content-Type",mime);
    c.setRequestProperty("x-upsert","true");

    OutputStream out=c.getOutputStream();
    byte[] buf=new byte[8192]; int n;
    while((n=in.read(buf))!=-1) out.write(buf,0,n);
    out.close(); in.close();

    int code=c.getResponseCode();
    if(code<200 || code>=300) throw new IOException("Storage upload failed: "+code);
    return SupabaseConfig.URL+"/storage/v1/object/public/"+bucket+"/"+objectPath;
  }
}