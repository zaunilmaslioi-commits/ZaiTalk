package com.zaitalk.app;

import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class NotificationManagerZT {
  private final Context ctx;
  public NotificationManagerZT(Context c){ctx=c;}

  public void load(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "notifications?user_id=eq."+SessionStore.getUserId()+
          "&select=*&order=created_at.desc&limit=50");
        new android.os.Handler(android.os.Looper.getMainLooper()).post(()->render(box,raw));
      }catch(Exception e){}
    }).start();
  }

  private void render(LinearLayout box,String raw){
    box.removeAllViews();
    try{
      org.json.JSONArray a=new org.json.JSONArray(raw);
      if(a.length()==0){
        TextView empty=new TextView(ctx);
        empty.setText("لا توجد إشعارات حالياً");
        empty.setTextColor(Color.WHITE);
        empty.setTextSize(16);
        empty.setPadding(20,30,20,30);
        box.addView(empty);
        return;
      }
      for(int i=0;i<a.length();i++){
        org.json.JSONObject n=a.getJSONObject(i);
        String id=n.optString("id");
        String body=n.optString("body","إشعار جديد");
        boolean read=n.optBoolean("is_read",false);

        LinearLayout row=new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(18,18,18,18);

        TextView title=new TextView(ctx);
        title.setText((read?"":"🔴 ")+body);
        title.setTextColor(Color.WHITE);
        title.setTextSize(read?15:16);
        row.addView(title);

        if(!read){
          Button b=new Button(ctx);
          b.setText("تحديد كمقروء");
          row.addView(b);
          b.setOnClickListener(v->markRead(id, row));
        }
        box.addView(row);
      }
    }catch(Exception ignored){}
  }

  private void markRead(String id,View row){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("is_read",true);
        SupabaseClient.patch("notifications?id=eq."+id,p.toString());
        new android.os.Handler(android.os.Looper.getMainLooper()).post(
          ()->row.setAlpha(0.55f));
      }catch(Exception ignored){}
    }).start();
  }

  public void unreadCount(TextView badge){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "notifications?user_id=eq."+SessionStore.getUserId()+
          "&is_read=eq.false&select=id");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        int count=a.length();
        new android.os.Handler(android.os.Looper.getMainLooper()).post(()->{
          if(count>0){
            badge.setText(String.valueOf(count));
            badge.setVisibility(View.VISIBLE);
          }else badge.setVisibility(View.GONE);
        });
      }catch(Exception ignored){}
    }).start();
  }
}