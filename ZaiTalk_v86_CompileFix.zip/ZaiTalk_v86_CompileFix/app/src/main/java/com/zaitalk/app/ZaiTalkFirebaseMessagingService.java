package com.zaitalk.app;

import android.app.*;
import android.content.*;
import androidx.annotation.NonNull;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class ZaiTalkFirebaseMessagingService extends FirebaseMessagingService {

  @Override public void onNewToken(@NonNull String token){
    saveToken(token);
  }

  @Override public void onMessageReceived(@NonNull RemoteMessage message){
    String title="ZaiTalk";
    String body="لديك إشعار جديد";
    if(message.getNotification()!=null){
      if(message.getNotification().getTitle()!=null)
        title=message.getNotification().getTitle();
      if(message.getNotification().getBody()!=null)
        body=message.getNotification().getBody();
    }
    showNotification(title,body);
  }

  private void saveToken(String token){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("user_id",SessionStore.getUserId());
        p.put("token",token);
        p.put("platform","android");
        SupabaseClient.insert("device_tokens",p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  private void showNotification(String title,String body){
    String channel="zaitalk_notifications";
    NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

    if(android.os.Build.VERSION.SDK_INT>=26){
      NotificationChannel c=new NotificationChannel(
        channel,"ZaiTalk Notifications",NotificationManager.IMPORTANCE_DEFAULT);
      nm.createNotificationChannel(c);
    }

    Intent i=new Intent(this,MainActivity.class);
    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(
      this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);

    Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26
      ?new Notification.Builder(this,channel)
      :new Notification.Builder(this);

    b.setSmallIcon(android.R.drawable.ic_dialog_info)
     .setContentTitle(title)
     .setContentText(body)
     .setAutoCancel(true)
     .setContentIntent(pi);

    nm.notify((int)(System.currentTimeMillis()%100000),b.build());
  }
}