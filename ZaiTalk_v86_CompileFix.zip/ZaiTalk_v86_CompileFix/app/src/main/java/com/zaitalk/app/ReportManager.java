package com.zaitalk.app;

import android.content.*;

public class ReportManager {
  private final Context ctx;
  public ReportManager(Context c){ctx=c;}

  public void reportUser(String userId,String reason){
    submit("user",userId,null,reason);
  }

  public void reportPost(String postId,String reason){
    submit("post",null,postId,reason);
  }

  private void submit(String type,String userId,String postId,String reason){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("reporter_id",SessionStore.getUserId());
        p.put("target_type",type);
        if(userId!=null)p.put("target_user_id",userId);
        if(postId!=null)p.put("target_post_id",postId);
        p.put("reason",reason);
        p.put("status","pending");
        SupabaseClient.insert("reports",p.toString());
      }catch(Exception ignored){}
    }).start();
  }
}