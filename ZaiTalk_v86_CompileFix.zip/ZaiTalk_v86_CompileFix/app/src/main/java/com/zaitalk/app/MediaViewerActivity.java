package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.net.Uri;
import android.graphics.BitmapFactory;
import java.net.*;

public class MediaViewerActivity extends Activity {
  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    String url=getIntent().getStringExtra("url");
    String type=getIntent().getStringExtra("type");
    FrameLayout root=new FrameLayout(this);
    root.setBackgroundColor(Color.BLACK);

    if("video".equalsIgnoreCase(type)){
      VideoView v=new VideoView(this);
      v.setVideoURI(Uri.parse(url));
      v.setMediaController(new MediaController(this));
      root.addView(v,new FrameLayout.LayoutParams(-1,-1));
    }else{
      ImageView iv=new ImageView(this);
      iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
      root.addView(iv,new FrameLayout.LayoutParams(-1,-1));
      new Thread(()->{
        try{
          HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
          android.graphics.Bitmap bm=BitmapFactory.decodeStream(c.getInputStream());
          runOnUiThread(()->iv.setImageBitmap(bm));
        }catch(Exception e){}
      }).start();
    }
    setContentView(root);
  }
}