package com.zaitalk.app;

import android.content.*;
import android.media.*;
import android.net.Uri;
import java.io.*;
import java.net.*;

public class VoiceRecorder {
  private MediaRecorder recorder;
  private File output;

  public String start(Context ctx) throws Exception {
    output=new File(ctx.getCacheDir(),"voice_"+System.currentTimeMillis()+".m4a");
    recorder=new MediaRecorder();
    recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
    recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
    recorder.setOutputFile(output.getAbsolutePath());
    recorder.prepare();
    recorder.start();
    return output.getAbsolutePath();
  }

  public String stop() {
    if(recorder!=null){
      try{recorder.stop();}catch(Exception ignored){}
      recorder.release(); recorder=null;
    }
    return output==null?null:output.getAbsolutePath();
  }

  public static String upload(Context ctx,String path,String bucket,String objectPath)throws Exception{
    File f=new File(path);
    FileInputStream in=new FileInputStream(f);
    String url=SupabaseConfig.URL+"/storage/v1/object/"+bucket+"/"+objectPath;
    HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
    c.setRequestMethod("POST"); c.setDoOutput(true);
    c.setRequestProperty("apikey",SupabaseConfig.KEY);
    c.setRequestProperty("Authorization","Bearer "+SessionStore.getToken());
    c.setRequestProperty("Content-Type","audio/mp4");
    c.setRequestProperty("x-upsert","true");
    OutputStream out=c.getOutputStream();
    byte[] buf=new byte[8192]; int n;
    while((n=in.read(buf))!=-1) out.write(buf,0,n);
    out.close(); in.close();
    int code=c.getResponseCode();
    if(code<200||code>=300)throw new IOException("Voice upload failed: "+code);
    return SupabaseConfig.URL+"/storage/v1/object/public/"+bucket+"/"+objectPath;
  }
}