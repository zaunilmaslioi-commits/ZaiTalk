package com.zaitalk.app;

import android.content.*;

public class PrivacyManager {
  private final Context ctx;
  public PrivacyManager(Context c){ctx=c;}

  public boolean get(String key, boolean fallback){
    return ctx.getSharedPreferences("privacy",Context.MODE_PRIVATE).getBoolean(key,fallback);
  }
  public void set(String key, boolean value){
    ctx.getSharedPreferences("privacy",Context.MODE_PRIVATE).edit().putBoolean(key,value).apply();
  }

  public boolean showLastSeen(){return get("show_last_seen",true);}
  public boolean showOnline(){return get("show_online",true);}
  public boolean readReceipts(){return get("read_receipts",true);}
}