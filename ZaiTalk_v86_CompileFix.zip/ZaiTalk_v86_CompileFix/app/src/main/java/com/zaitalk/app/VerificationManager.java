package com.zaitalk.app;

import android.content.*;

public class VerificationManager {
  private final Context ctx;
  public VerificationManager(Context c){ctx=c;}

  public void request(String note){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("user_id",SessionStore.getUserId());
        p.put("note",note);
        p.put("status","pending");
        SupabaseClient.insert("verification_requests",p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public boolean isVerified(String userId){
    try{
      String raw=SupabaseClient.select("profiles?id=eq."+userId+"&select=is_verified");
      org.json.JSONArray a=new org.json.JSONArray(raw);
      return a.length()>0 && a.getJSONObject(0).optBoolean("is_verified",false);
    }catch(Exception e){return false;}
  }
}