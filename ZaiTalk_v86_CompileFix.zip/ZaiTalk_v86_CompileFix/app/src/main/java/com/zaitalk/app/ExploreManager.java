package com.zaitalk.app;

import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class ExploreManager {
  private final MainActivity a;
  public ExploreManager(MainActivity x){a=x;}

  public void search(String query,LinearLayout users,LinearLayout posts){
    new Thread(()->{
      try{
        String q=query.trim().replace(" ","%20");
        String u=SupabaseClient.select(
          "profiles?or=(username.ilike.*"+q+"*,display_name.ilike.*"+q+"*)&select=id,username,display_name,is_verified,is_private&limit=20");
        String p=SupabaseClient.select(
          "posts?content=ilike.*"+q+"*&select=*&order=created_at.desc&limit=30");
        a.runOnUiThread(()->{
          renderUsers(users,u);
          renderPosts(posts,p);
        });
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر تنفيذ البحث",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }

  private void renderUsers(LinearLayout box,String raw){
    box.removeAllViews();
    try{
      JSONArray arr=new JSONArray(raw);
      for(int i=0;i<arr.length();i++){
        JSONObject x=arr.getJSONObject(i);
        TextView t=new TextView(a);
        String name=x.optString("display_name",x.optString("username","مستخدم"));
        String verified=x.optBoolean("is_verified",false)?" ✓":"";
        t.setText("👤 "+name+verified);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setPadding(10,14,10,14);
        box.addView(t);
      }
    }catch(Exception ignored){}
  }

  private void renderPosts(LinearLayout box,String raw){
    box.removeAllViews();
    try{
      JSONArray arr=new JSONArray(raw);
      for(int i=0;i<arr.length();i++){
        JSONObject x=arr.getJSONObject(i);
        TextView t=new TextView(a);
        t.setText("📝 "+x.optString("content",x.optString("caption","منشور")));
        t.setTextColor(Color.LTGRAY);
        t.setTextSize(15);
        t.setPadding(10,14,10,14);
        box.addView(t);
      }
    }catch(Exception ignored){}
  }

  public void suggestions(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "profiles?select=id,username,display_name,is_verified&order=created_at.desc&limit=10");
        a.runOnUiThread(()->renderUsers(box,raw));
      }catch(Exception ignored){}
    }).start();
  }
}