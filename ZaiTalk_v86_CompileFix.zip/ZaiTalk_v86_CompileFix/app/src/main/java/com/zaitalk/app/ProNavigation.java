package com.zaitalk.app;

import android.app.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;

public class ProNavigation {
  private final MainActivity a;
  private LinearLayout root, content, nav;

  public ProNavigation(MainActivity activity){a=activity;}

  public void setup(){
    root=new LinearLayout(a);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setBackgroundColor(Color.rgb(15,15,18));

    content=new LinearLayout(a);
    content.setOrientation(LinearLayout.VERTICAL);
    content.setPadding(18,18,18,12);

    ScrollView scroll=new ScrollView(a);
    scroll.addView(content);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

    nav=new LinearLayout(a);
    nav.setGravity(Gravity.CENTER);
    nav.setPadding(4,4,4,4);
    nav.setBackgroundColor(Color.rgb(25,25,30));

    addNav("⌂","الرئيسية",0);
    addNav("⌕","استكشاف",1);
    addNav("▶","ريلز",2);
    addNav("✉","محادثات",3);
    addNav("◉","حسابي",4);

    root.addView(nav,new LinearLayout.LayoutParams(-1,68));
    a.setContentView(root);
    home();
  }

  private void addNav(String icon,String label,int index){
    Button b=new Button(a);
    b.setText(icon+"\\n"+label);
    b.setTextColor(Color.WHITE);
    b.setTextSize(11);
    b.setAllCaps(false);
    b.setBackgroundColor(Color.TRANSPARENT);
    nav.addView(b,new LinearLayout.LayoutParams(0,-1,1));
    b.setOnClickListener(v->select(index));
  }

  private void select(int i){
    if(i==0)home();
    else if(i==1)explore();
    else if(i==2)reels();
    else if(i==3)chat();
    else profile();
  }

  private void clear(String title){
    content.removeAllViews();
    TextView t=new TextView(a);
    t.setText(title);
    t.setTextColor(Color.WHITE);
    t.setTextSize(27);
    t.setPadding(4,8,4,22);
    content.addView(t);
  }

  private void item(String text){
    TextView t=new TextView(a);
    t.setText(text);
    t.setTextColor(Color.LTGRAY);
    t.setTextSize(16);
    t.setPadding(8,18,8,18);
    content.addView(t);
  }

  public void home(){
    clear("ZaiTalk");
    item("✨ آخر المنشورات");
    item("❤️ الإعجابات والتعليقات تظهر هنا");
    item("📸 شارك لحظتك مع أصدقائك");
  }

  public void explore(){
    clear("استكشاف");
    item("🔎 ابحث عن أشخاص ومنشورات");
    item("🔥 الأكثر تفاعلاً");
    item("👥 اقتراحات المتابعة");
  }

  public void reels(){
    clear("Reels");
    item("▶ الفيديوهات القصيرة");
    item("اسحب للتصفح بين المقاطع");
  }

  public void chat(){
    clear("المحادثات");
    item("✉ رسائلك");
    item("🟢 المتصلون الآن");
  }

  public void profile(){
    clear("حسابي");
    item("◉ الملف الشخصي");
    item("⚙ الإعدادات والخصوصية");
    item("🔔 الإشعارات");
  }
}