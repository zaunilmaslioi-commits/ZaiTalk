package com.zaitalk.app;

import android.content.*;

public class PrivacySync {
  private final Context ctx;
  private final PrivacyManager local;
  public PrivacySync(Context c){ctx=c; local=new PrivacyManager(c);}

  public void saveToCloud(){
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        if(uid==null||uid.isEmpty())return;
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("privacy_show_last_seen",local.showLastSeen());
        p.put("privacy_show_online",local.showOnline());
        p.put("privacy_read_receipts",local.readReceipts());
        SupabaseClient.patch("profiles?id=eq."+uid,p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public void loadFromCloud(){
    new Thread(()->{
      try{
        String uid=SessionStore.getUserId();
        if(uid==null||uid.isEmpty())return;
        String raw=SupabaseClient.select("profiles?id=eq."+uid+"&select=privacy_show_last_seen,privacy_show_online,privacy_read_receipts");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        if(a.length()==0)return;
        org.json.JSONObject p=a.getJSONObject(0);
        if(p.has("privacy_show_last_seen")) local.set("show_last_seen",p.optBoolean("privacy_show_last_seen",true));
        if(p.has("privacy_show_online")) local.set("show_online",p.optBoolean("privacy_show_online",true));
        if(p.has("privacy_read_receipts")) local.set("read_receipts",p.optBoolean("privacy_read_receipts",true));
      }catch(Exception ignored){}
    }).start();
  }
}