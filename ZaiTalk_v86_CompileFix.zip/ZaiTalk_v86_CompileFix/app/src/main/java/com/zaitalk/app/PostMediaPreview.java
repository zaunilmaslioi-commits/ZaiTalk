package com.zaitalk.app;
import android.app.AlertDialog;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class PostMediaPreview {
  private final MainActivity a;
  public PostMediaPreview(MainActivity activity){a=activity;}

  public void show(Uri uri,String mime){
    LinearLayout box=new LinearLayout(a);
    box.setOrientation(LinearLayout.VERTICAL);
    box.setPadding(16,16,16,16);

    if(mime!=null && mime.startsWith("video/")){
      VideoView video=new VideoView(a);
      video.setVideoURI(uri);
      video.setLayoutParams(new LinearLayout.LayoutParams(-1,420));
      box.addView(video);
      video.setOnPreparedListener(mp->{
        mp.setLooping(true);
        video.start();
      });
    }else{
      ImageView image=new ImageView(a);
      image.setImageURI(uri);
      image.setAdjustViewBounds(true);
      image.setScaleType(ImageView.ScaleType.CENTER_CROP);
      box.addView(image);
    }

    EditText caption=new EditText(a);
    caption.setHint("اكتب وصف المنشور...");
    caption.setTextColor(Color.WHITE);
    caption.setHintTextColor(Color.GRAY);
    box.addView(caption);

    new AlertDialog.Builder(a)
      .setTitle("معاينة المنشور")
      .setView(box)
      .setNegativeButton("إلغاء",null)
      .setPositiveButton("نشر",(d,w)->{
        a.toastPublic("تم تجهيز المنشور للنشر ✅");
      }).show();
  }
}
