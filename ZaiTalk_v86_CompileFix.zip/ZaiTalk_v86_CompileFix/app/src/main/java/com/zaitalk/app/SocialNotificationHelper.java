package com.zaitalk.app;

import org.json.JSONObject;

public class SocialNotificationHelper {
  public static void send(String userId,String type,String body,String referenceId){
    new Thread(()->{
      try{
        if(userId==null || userId.isEmpty()) return;
        if(userId.equals(SessionStore.getUserId())) return;

        JSONObject n=new JSONObject();
        n.put("user_id",userId);
        n.put("type",type);
        n.put("body",body);
        n.put("reference_id",referenceId==null?"":referenceId);
        SupabaseClient.insert("notifications",n.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public static void like(String ownerId,String postId){
    send(ownerId,"like","أعجب شخص بمنشورك",postId);
  }

  public static void comment(String ownerId,String postId){
    send(ownerId,"comment","تمت إضافة تعليق على منشورك",postId);
  }

  public static void message(String receiverId,String messageId){
    send(receiverId,"message","لديك رسالة جديدة",messageId);
  }

  public static void follow(String targetId){
    send(targetId,"follow_request","لديك طلب متابعة جديد",SessionStore.getUserId());
  }
}