package com.zaitalk.app;

import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;
import org.json.*;

public class ReelsAdapter extends android.widget.BaseAdapter {
  private final MainActivity a;
  private final ArrayList<JSONObject> items;
  public ReelsAdapter(MainActivity activity,ArrayList<JSONObject> data){
    a=activity; items=data;
  }
  public int getCount(){return items.size();}
  public Object getItem(int p){return items.get(p);}
  public long getItemId(int p){return p;}

  public View getView(int p,View convert,android.view.ViewGroup parent){
    JSONObject x=items.get(p);
    FrameLayout box=new FrameLayout(a);
    box.setBackgroundColor(Color.BLACK);

    VideoView video=new VideoView(a);
    box.addView(video,new FrameLayout.LayoutParams(-1,-1));
    String url=x.optString("media_url","");
    if(!url.isEmpty()) MediaPlayerHelper.playVideo(a,video,url);

    LinearLayout overlay=new LinearLayout(a);
    overlay.setOrientation(LinearLayout.VERTICAL);
    overlay.setPadding(22,22,22,45);

    TextView caption=new TextView(a);
    caption.setText(x.optString("content",x.optString("caption","")));
    caption.setTextColor(Color.WHITE);
    caption.setTextSize(18);

    Button like=new Button(a);
    like.setText("❤️ إعجاب");
    Button comment=new Button(a);
    comment.setText("💬 تعليق");
    Button share=new Button(a);
    share.setText("↗ مشاركة");

    overlay.addView(caption);
    overlay.addView(like);
    overlay.addView(comment);
    overlay.addView(share);

    FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(
      -1,-2,Gravity.BOTTOM);
    box.addView(overlay,op);

    like.setOnClickListener(v->a.toastPublic("تم الإعجاب ❤️"));
    comment.setOnClickListener(v->a.toastPublic("فتح التعليقات 💬"));
    share.setOnClickListener(v->a.toastPublic("مشاركة الريل ↗"));

    return box;
  }
}