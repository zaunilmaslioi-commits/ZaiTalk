package com.zaitalk.app;

import android.content.*;
import okhttp3.*;
import org.json.*;

public class NotificationRealtime {
  private final Context ctx;
  private WebSocket socket;

  public NotificationRealtime(Context c){ctx=c;}

  public void connect(){
    try{
      String url=SupabaseConfig.getUrl().replace("https://","wss://")
        +"/realtime/v1/websocket?apikey="+SupabaseConfig.getKey()+"&vsn=1.0.0";
      OkHttpClient client=new OkHttpClient();
      Request request=new Request.Builder().url(url).build();

      socket=client.newWebSocket(request,new WebSocketListener(){
        @Override public void onOpen(WebSocket ws,Response r){
          String uid=SessionStore.getUserId();
          String join="{\"topic\":\"realtime:notifications_"+uid+
            "\",\"event\":\"phx_join\",\"payload\":{},\"ref\":\"1\"}";
          ws.send(join);
        }

        @Override public void onMessage(WebSocket ws,String text){
          try{
            JSONObject root=new JSONObject(text);
            String event=root.optString("event","");
            if(event.equals("postgres_changes") || text.contains("\"INSERT\"")){
              JSONObject payload=root.optJSONObject("payload");
              JSONObject rec=payload==null?null:payload.optJSONObject("record");
              if(rec!=null){
                String type=rec.optString("type","notification");
                String ref=rec.optString("reference_id","");
                android.os.Handler h=new android.os.Handler(
                  android.os.Looper.getMainLooper());
                h.post(()->{
                  android.widget.Toast.makeText(ctx,
                    "🔔 "+rec.optString("body","إشعار جديد"),
                    android.widget.Toast.LENGTH_LONG).show();
                  NotificationRouter.open(ctx,type,ref);
                });
              }
            }
          }catch(Exception ignored){}
        }
      });
    }catch(Exception ignored){}
  }

  public void close(){
    if(socket!=null) socket.close(1000,"closed");
  }
}