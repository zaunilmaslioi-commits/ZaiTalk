package com.zaitalk.app;

import android.graphics.Color;
import android.widget.*;
import org.json.*;
import java.util.*;

public class HashtagManager {
  private final MainActivity a;
  public HashtagManager(MainActivity x){a=x;}

  public void trending(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?select=id,content,caption,created_at&order=created_at.desc&limit=100");
        HashMap<String,Integer> counts=new HashMap<>();
        JSONArray arr=new JSONArray(raw);

        for(int i=0;i<arr.length();i++){
          JSONObject p=arr.getJSONObject(i);
          String text=p.optString("content",p.optString("caption",""));
          java.util.regex.Matcher m=java.util.regex.Pattern
            .compile("#([\\p{L}\\p{N}_]+)")
            .matcher(text);
          while(m.find()){
            String tag="#"+m.group(1).toLowerCase();
            counts.put(tag,counts.containsKey(tag)?counts.get(tag)+1:1);
          }
        }

        ArrayList<Map.Entry<String,Integer>> list=
          new ArrayList<>(counts.entrySet());
        Collections.sort(list,(x,y)->y.getValue()-x.getValue());

        a.runOnUiThread(()->{
          box.removeAllViews();
          int max=Math.min(15,list.size());
          for(int i=0;i<max;i++){
            TextView t=new TextView(a);
            t.setText("🔥 "+list.get(i).getKey()+"   "+list.get(i).getValue()+" منشور");
            t.setTextColor(Color.WHITE);
            t.setTextSize(17);
            t.setPadding(12,16,12,16);
            box.addView(t);
          }
          if(max==0){
            TextView t=new TextView(a);
            t.setText("لا توجد Hashtags رائجة حالياً");
            t.setTextColor(Color.LTGRAY);
            box.addView(t);
          }
        });
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر تحميل الترند",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }
}