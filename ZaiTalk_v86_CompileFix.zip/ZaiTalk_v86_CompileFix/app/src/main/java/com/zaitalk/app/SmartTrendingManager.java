package com.zaitalk.app;

import android.graphics.Color;
import android.widget.*;
import org.json.*;
import java.util.*;

public class SmartTrendingManager {
  private final MainActivity a;
  public SmartTrendingManager(MainActivity x){a=x;}

  public void load(LinearLayout box){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?select=id,content,caption,created_at,views,likes_count,comments_count&order=created_at.desc&limit=100");
        JSONArray arr=new JSONArray(raw);
        ArrayList<PostScore> posts=new ArrayList<>();

        for(int i=0;i<arr.length();i++){
          JSONObject p=arr.getJSONObject(i);
          int likes=p.optInt("likes_count",0);
          int comments=p.optInt("comments_count",0);
          int views=p.optInt("views",0);
          double score=likes*3.0 + comments*5.0 + views*0.25;
          posts.add(new PostScore(p.optString("content",p.optString("caption","")),score));
        }

        Collections.sort(posts,(x,y)->Double.compare(y.score,x.score));

        a.runOnUiThread(()->{
          box.removeAllViews();
          int max=Math.min(20,posts.size());
          for(int i=0;i<max;i++){
            TextView t=new TextView(a);
            t.setText("🔥 "+(i+1)+"  "+posts.get(i).text+
              "\n⭐ Trend score: "+Math.round(posts.get(i).score));
            t.setTextColor(Color.WHITE);
            t.setTextSize(16);
            t.setPadding(12,18,12,18);
            box.addView(t);
          }
        });
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر تحميل الترند الذكي",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }

  static class PostScore{
    String text; double score;
    PostScore(String t,double s){text=t;score=s;}
  }
}