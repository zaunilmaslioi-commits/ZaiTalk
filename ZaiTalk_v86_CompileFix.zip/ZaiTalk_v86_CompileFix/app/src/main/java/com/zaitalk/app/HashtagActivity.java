package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.widget.*;

public class HashtagActivity extends Activity {
  EditText input;
  LinearLayout results;
  Button follow;

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    LinearLayout root=new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(16,16,16,16);
    root.setBackgroundColor(Color.rgb(15,15,18));

    TextView title=new TextView(this);
    title.setText("🏷️ Hashtag");
    title.setTextColor(Color.WHITE);
    title.setTextSize(25);

    input=new EditText(this);
    input.setHint("#هاشتاغ");
    input.setSingleLine(true);
    input.setTextColor(Color.WHITE);
    input.setHintTextColor(Color.GRAY);

    LinearLayout actions=new LinearLayout(this);
    actions.setOrientation(LinearLayout.HORIZONTAL);

    Button search=new Button(this);
    search.setText("بحث");
    follow=new Button(this);
    follow.setText("＋ متابعة");

    actions.addView(search,new LinearLayout.LayoutParams(0,-2,1));
    actions.addView(follow,new LinearLayout.LayoutParams(0,-2,1));

    results=new LinearLayout(this);
    results.setOrientation(LinearLayout.VERTICAL);
    ScrollView scroll=new ScrollView(this);
    scroll.addView(results);

    root.addView(title);
    root.addView(input);
    root.addView(actions);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    setContentView(root);

    search.setOnClickListener(v->showInfo("يتم تحميل منشورات "+input.getText()));
    follow.setOnClickListener(v->{
      String tag=input.getText().toString().trim();
      if(!tag.isEmpty()) showInfo("تمت متابعة "+tag);
    });
  }

  private void showInfo(String s){
    results.removeAllViews();
    TextView t=new TextView(this);
    t.setText(s);
    t.setTextColor(Color.LTGRAY);
    t.setTextSize(16);
    t.setPadding(8,20,8,20);
    results.addView(t);
  }
}