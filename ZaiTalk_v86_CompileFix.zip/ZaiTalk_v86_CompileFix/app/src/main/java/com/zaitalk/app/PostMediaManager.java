package com.zaitalk.app;

import android.content.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.*;
import org.json.*;

public class PostMediaManager {
  private final MainActivity a;
  public PostMediaManager(MainActivity activity){a=activity;}

  public void upload(Uri uri,String postId,String mime){
    new Thread(()->{
      try{
        String ext=mime!=null && mime.contains("video")?".mp4":".jpg";
        String path=SessionStore.getUserId()+"/"+postId+"_"+System.currentTimeMillis()+ext;

        InputStream in=a.getContentResolver().openInputStream(uri);
        if(in==null) throw new IOException("cannot open uri");

        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buf=new byte[8192];
        int n;
        while((n=in.read(buf))!=-1) out.write(buf,0,n);
        in.close();

        // Storage endpoint for the public post-media bucket.
        SupabaseClient.uploadStorage("post-media",path,
          out.toByteArray(),mime==null?"image/jpeg":mime);

        String publicUrl=SupabaseClient.storagePublicUrl("post-media",path);

        JSONObject patch=new JSONObject();
        patch.put("media_url",publicUrl);
        patch.put("media_type",mime!=null && mime.contains("video")?"video":"image");
        SupabaseClient.patch("posts?id=eq."+postId,patch.toString());

        a.runOnUiThread(()->a.toastPublic("تم رفع الوسائط ونشرها ✅"));
      }catch(Exception e){
        a.runOnUiThread(()->a.toastPublic("تعذر رفع الوسائط"));
      }
    }).start();
  }
}