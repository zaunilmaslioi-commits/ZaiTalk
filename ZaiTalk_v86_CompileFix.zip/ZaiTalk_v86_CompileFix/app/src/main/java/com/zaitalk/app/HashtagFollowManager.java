package com.zaitalk.app;

import android.content.Context;
import android.widget.Toast;
import org.json.JSONObject;

public class HashtagFollowManager {
  private final MainActivity a;
  private final SessionStore session;

  public HashtagFollowManager(MainActivity x){
    a=x;
    session=new SessionStore(x);
  }

  public void follow(String tag){
    final String clean=tag.replace("#","").trim().toLowerCase();
    if(clean.isEmpty()) return;
    new Thread(()->{
      try{
        JSONObject body=new JSONObject();
        body.put("user_id",session.uid());
        body.put("tag",clean);
        SupabaseClient db=new SupabaseClient();
        db.token(session.token());
        db.insertAuth("followed_hashtags",body);
        a.runOnUiThread(()->Toast.makeText(a,
          "تمت متابعة #"+clean,Toast.LENGTH_SHORT).show());
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر متابعة الهاشتاغ",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }

  public void unfollow(String tag){
    final String clean=tag.replace("#","").trim().toLowerCase();
    if(clean.isEmpty()) return;
    new Thread(()->{
      try{
        SupabaseClient db=new SupabaseClient();
        db.token(session.token());
        db.deleteAuth("followed_hashtags",
          "user_id=eq."+session.uid()+"&tag=eq."+clean);
        a.runOnUiThread(()->Toast.makeText(a,
          "تم إلغاء متابعة #"+clean,Toast.LENGTH_SHORT).show());
      }catch(Exception ignored){}
    }).start();
  }
}