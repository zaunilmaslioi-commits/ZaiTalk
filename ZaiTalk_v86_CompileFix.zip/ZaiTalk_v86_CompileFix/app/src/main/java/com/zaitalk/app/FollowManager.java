package com.zaitalk.app;

import android.content.*;

public class FollowManager {
  private final Context ctx;
  public FollowManager(Context c){ctx=c;}

  public void request(String targetId){
    new Thread(()->{
      try{
        String me=SessionStore.getUserId();
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("follower_id",me);
        p.put("following_id",targetId);
        p.put("status","pending");
        SupabaseClient.insert("follow_requests",p.toString());
        notifyUser(targetId,"follow_request","لديك طلب متابعة جديد من "+me);
      }catch(Exception ignored){}
    }).start();
  }

  public void approve(String requestId){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select("follow_requests?id=eq."+requestId+"&select=*");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        if(a.length()==0)return;
        org.json.JSONObject r=a.getJSONObject(0);
        String follower=r.optString("follower_id");
        String following=r.optString("following_id");

        org.json.JSONObject f=new org.json.JSONObject();
        f.put("follower_id",follower);
        f.put("following_id",following);
        SupabaseClient.insert("follows",f.toString());

        org.json.JSONObject p=new org.json.JSONObject(); p.put("status","accepted");
        SupabaseClient.patch("follow_requests?id=eq."+requestId,p.toString());

        notifyUser(follower,"follow_accepted","تم قبول طلب المتابعة الخاص بك");
      }catch(Exception ignored){}
    }).start();
  }

  public void reject(String requestId){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select("follow_requests?id=eq."+requestId+"&select=follower_id");
        org.json.JSONArray a=new org.json.JSONArray(raw);
        String follower=a.length()>0?a.getJSONObject(0).optString("follower_id"):"";
        org.json.JSONObject p=new org.json.JSONObject(); p.put("status","rejected");
        SupabaseClient.patch("follow_requests?id=eq."+requestId,p.toString());
        if(!follower.isEmpty()) notifyUser(follower,"follow_rejected","تم رفض طلب المتابعة");
      }catch(Exception ignored){}
    }).start();
  }

  public void setPrivate(boolean value){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject(); p.put("is_private",value);
        SupabaseClient.patch("profiles?id=eq."+SessionStore.getUserId(),p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  private void notifyUser(String userId,String type,String body){
    try{
      org.json.JSONObject n=new org.json.JSONObject();
      n.put("user_id",userId);
      n.put("type",type);
      n.put("body",body);
      SupabaseClient.insert("notifications",n.toString());
    }catch(Exception ignored){}
  }
}