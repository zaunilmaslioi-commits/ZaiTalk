package com.zaitalk.app;

import android.content.*;

public class NotificationRouter {
  public static void open(Context ctx,String type,String refId){
    try{
      Intent i=new Intent(ctx,MainActivity.class);
      i.putExtra("notification_type",type);
      i.putExtra("notification_ref",refId);
      i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
      ctx.startActivity(i);
    }catch(Exception ignored){}
  }
}