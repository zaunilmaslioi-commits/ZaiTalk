package com.zaitalk.app;

import org.json.*;

public class ReelsInteractionManager {

  public static int countLikes(String postId) throws Exception{
    String raw=SupabaseClient.select("likes?post_id=eq."+postId+"&select=id");
    return new JSONArray(raw).length();
  }

  public static int countComments(String postId) throws Exception{
    String raw=SupabaseClient.select("comments?post_id=eq."+postId+"&select=id");
    return new JSONArray(raw).length();
  }

  public static boolean isFollowing(String userId) throws Exception{
    String raw=SupabaseClient.select(
      "follows?follower_id=eq."+SessionStore.getUserId()+
      "&following_id=eq."+userId+"&select=id");
    return new JSONArray(raw).length()>0;
  }

  public static void follow(String userId) throws Exception{
    JSONObject p=new JSONObject();
    p.put("follower_id",SessionStore.getUserId());
    p.put("following_id",userId);
    SupabaseClient.insert("follows",p.toString());
    SocialNotificationHelper.follow(userId);
  }

  public static void save(String postId) throws Exception{
    JSONObject p=new JSONObject();
    p.put("user_id",SessionStore.getUserId());
    p.put("post_id",postId);
    SupabaseClient.insert("saves",p.toString());
  }
}