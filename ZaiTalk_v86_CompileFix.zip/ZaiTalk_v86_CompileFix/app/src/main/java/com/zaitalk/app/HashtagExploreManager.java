package com.zaitalk.app;

import android.graphics.Color;
import android.widget.*;
import org.json.*;
import java.util.*;

public class HashtagExploreManager {
  private final MainActivity a;
  public HashtagExploreManager(MainActivity x){a=x;}

  public void searchHashtag(String tag, LinearLayout box){
    new Thread(()->{
      try{
        String clean=tag.replace("#","").trim().toLowerCase();
        String raw=SupabaseClient.select(
          "posts?select=id,content,caption,created_at,views,likes_count,comments_count&order=created_at.desc&limit=100");
        JSONArray arr=new JSONArray(raw);

        a.runOnUiThread(()->{
          box.removeAllViews();
          TextView h=new TextView(a);
          h.setText("🏷️ #"+clean);
          h.setTextColor(Color.WHITE);
          h.setTextSize(24);
          h.setPadding(8,8,8,18);
          box.addView(h);

          int found=0;
          try{
            for(int i=0;i<arr.length();i++){
              JSONObject p=arr.getJSONObject(i);
              String text=p.optString("content",p.optString("caption",""));
              if(text.toLowerCase().contains("#"+clean)){
                TextView t=new TextView(a);
                t.setText(text+"\n❤️ "+p.optInt("likes_count",0)+
                  "   💬 "+p.optInt("comments_count",0)+
                  "   👁️ "+p.optInt("views",0));
                t.setTextColor(Color.LTGRAY);
                t.setTextSize(16);
                t.setPadding(12,16,12,16);
                box.addView(t);
                found++;
                if(found>=30) break;
              }
            }
          }catch(Exception ignored){}

          if(found==0){
            TextView empty=new TextView(a);
            empty.setText("ماكو منشورات لهذا الهاشتاغ حالياً");
            empty.setTextColor(Color.GRAY);
            empty.setPadding(8,20,8,20);
            box.addView(empty);
          }
        });
      }catch(Exception e){
        a.runOnUiThread(()->Toast.makeText(a,
          "تعذر البحث عن الهاشتاغ",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }
}