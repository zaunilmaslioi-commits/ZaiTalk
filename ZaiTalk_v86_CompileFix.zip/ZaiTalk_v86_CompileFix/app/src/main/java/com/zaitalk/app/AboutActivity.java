package com.zaitalk.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class AboutActivity extends Activity {
  @Override protected void onCreate(Bundle b){
    super.onCreate(b);

    LinearLayout root=new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setGravity(Gravity.CENTER_HORIZONTAL);
    root.setPadding(24,40,24,24);
    root.setBackgroundColor(Color.rgb(15,15,18));

    TextView logo=new TextView(this);
    logo.setText("ZaiTalk");
    logo.setTextColor(Color.WHITE);
    logo.setTextSize(34);
    logo.setGravity(Gravity.CENTER);

    TextView version=new TextView(this);
    version.setText("الإصدار 1.0.0");
    version.setTextColor(Color.LTGRAY);
    version.setTextSize(16);
    version.setPadding(0,10,0,30);

    TextView info=new TextView(this);
    info.setText(
      "منصة اجتماعية للتواصل والمشاركة.\n\n"+
      "منشورات • Reels • Chat • Explore • Hashtags • Trending\n\n"+
      "© ZaiTalk"
    );
    info.setTextColor(Color.WHITE);
    info.setTextSize(17);
    info.setGravity(Gravity.CENTER);
    info.setPadding(0,10,0,30);

    Button support=new Button(this);
    support.setText("الدعم والمساعدة");
    support.setOnClickListener(v->
      Toast.makeText(this,"تواصل مع دعم ZaiTalk من قناة الدعم الرسمية.",
        Toast.LENGTH_LONG).show());

    root.addView(logo);
    root.addView(version);
    root.addView(info);
    root.addView(support);
    setContentView(root);
  }
}