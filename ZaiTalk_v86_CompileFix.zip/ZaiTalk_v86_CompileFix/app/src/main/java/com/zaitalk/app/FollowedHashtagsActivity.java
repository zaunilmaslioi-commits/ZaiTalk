package com.zaitalk.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import org.json.*;

public class FollowedHashtagsActivity extends Activity {
  LinearLayout box;
  SessionStore session;

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    session=new SessionStore(this);

    LinearLayout root=new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(18,18,18,18);
    root.setBackgroundColor(Color.rgb(15,15,18));

    TextView title=new TextView(this);
    title.setText("🏷️ الهاشتاغات التي أتابعها");
    title.setTextColor(Color.WHITE);
    title.setTextSize(23);

    box=new LinearLayout(this);
    box.setOrientation(LinearLayout.VERTICAL);

    ScrollView sc=new ScrollView(this);
    sc.addView(box);
    root.addView(title);
    root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    setContentView(root);

    load();
  }

  void load(){
    new Thread(()->{
      try{
        SupabaseClient db=new SupabaseClient();
        db.token(session.token());
        JSONArray a=db.selectAuth("followed_hashtags",
          "select=tag,created_at&user_id=eq."+session.uid()+"&order=created_at.desc");
        runOnUiThread(()->{
          box.removeAllViews();
          for(int i=0;i<a.length();i++){
            TextView t=new TextView(this);
            t.setText("🏷️ #"+a.optJSONObject(i).optString("tag"));
            t.setTextColor(Color.WHITE);
            t.setTextSize(17);
            t.setPadding(10,16,10,16);
            box.addView(t);
          }
          if(a.length()==0){
            TextView e=new TextView(this);
            e.setText("ما تتابع أي هاشتاغ حالياً.");
            e.setTextColor(Color.GRAY);
            e.setPadding(10,20,10,20);
            box.addView(e);
          }
        });
      }catch(Exception e){
        runOnUiThread(()->Toast.makeText(this,
          "تعذر تحميل الهاشتاغات",Toast.LENGTH_SHORT).show());
      }
    }).start();
  }
}