package com.zaitalk.app;

import android.content.*;
import java.util.*;

public class BlockManager {
  private final Context ctx;
  public BlockManager(Context c){ctx=c;}

  public void block(String userId){
    new Thread(()->{
      try{
        org.json.JSONObject p=new org.json.JSONObject();
        p.put("blocker_id",SessionStore.getUserId());
        p.put("blocked_id",userId);
        SupabaseClient.insert("blocks",p.toString());
      }catch(Exception ignored){}
    }).start();
  }

  public void unblock(String userId){
    new Thread(()->{
      try{
        SupabaseClient.delete("blocks?blocker_id=eq."+SessionStore.getUserId()+"&blocked_id=eq."+userId);
      }catch(Exception ignored){}
    }).start();
  }

  public boolean isBlocked(String userId){
    try{
      String uid=SessionStore.getUserId();
      String raw=SupabaseClient.select("blocks?or=(and(blocker_id.eq."+uid+",blocked_id.eq."+userId+"),and(blocker_id.eq."+userId+",blocked_id.eq."+uid+"))&select=id");
      org.json.JSONArray a=new org.json.JSONArray(raw);
      return a.length()>0;
    }catch(Exception e){ return false; }
  }
}