package com.zaitalk.app;

import android.content.*;
import android.media.MediaPlayer;
import android.view.*;
import android.widget.*;
import java.io.*;

public class VoiceMessageView {
  public static View create(Context ctx,String url){
    LinearLayout box=new LinearLayout(ctx);
    box.setOrientation(LinearLayout.HORIZONTAL);
    box.setPadding(12,8,12,8);
    Button play=new Button(ctx); play.setText("▶ صوت");
    TextView state=new TextView(ctx); state.setText("  جاهز");
    box.addView(play); box.addView(state);

    play.setOnClickListener(v->{
      try{
        MediaPlayer mp=new MediaPlayer();
        mp.setDataSource(url);
        mp.setOnPreparedListener(x->{state.setText("  يعمل الآن"); x.start();});
        mp.setOnCompletionListener(x->{state.setText("  انتهى"); x.release();});
        mp.setOnErrorListener((x,a,b)->{state.setText("  تعذر التشغيل"); x.release(); return true;});
        mp.prepareAsync();
      }catch(Exception e){state.setText("  تعذر التشغيل");}
    });
    return box;
  }
}