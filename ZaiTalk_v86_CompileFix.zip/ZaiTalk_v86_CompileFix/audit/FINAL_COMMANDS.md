# Final commands

From the project root:

```bash
./gradlew clean
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
```

If the wrapper is not present or executable, open the project in Android
Studio and use Gradle Sync / Build from the IDE.

Never place release passwords, signing keys, service-role keys, or Firebase
service-account private keys in the project archive.
