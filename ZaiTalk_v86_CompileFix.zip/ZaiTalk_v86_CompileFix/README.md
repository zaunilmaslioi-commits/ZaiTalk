# ZaiTalk v74 — Mobile Build

نسخة مخصصة للمستخدم الذي يعمل من Android فقط.

تمت إضافة:
- GitHub Actions workflow لبناء Debug APK على السحابة.
- دليل عربي خطوة بخطوة من الهاتف.
- Artifact قابل للتنزيل بعد نجاح الـbuild.

مهم: الـworkflow لا يضمن نجاح compile؛ إذا ظهرت أخطاء Java/Gradle في Actions
أرسلها هنا ونصلحها. لا تضع أسرار الخادم داخل GitHub repository.
