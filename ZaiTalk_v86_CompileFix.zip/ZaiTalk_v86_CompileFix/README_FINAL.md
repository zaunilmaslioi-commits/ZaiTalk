# ZaiTalk v64 — Final Development Release

هذه النسخة تجمع آخر مراحل ZaiTalk التي بنيناها:
- تسجيل ودخول واسترجاع كلمة المرور وتأكيد البريد.
- منشورات وتفاعل وإعجابات وتعليقات وحفظ ومشاركة.
- Reels وفيديوهات ووسائط.
- Chat مباشر ووسائط ورسائل صوتية وحالات قراءة.
- الخصوصية والحظر والإبلاغ والإدارة والتحقق والحسابات الخاصة.
- Follow requests وNotifications وRealtime وPush architecture.
- Explore وSearch وHashtags وTrending.
- متابعة الهاشتاغات وقائمة الهاشتاغات المتابعة.
- تجهيز Edge Function لإشعارات الهاشتاغ من الخادم.

## قبل التشغيل
1. ضع بيانات Supabase في `local.properties` حسب المثال.
2. شغّل ملفات SQL السابقة بالترتيب، أو استخدم `supabase/final_release.sql`
   بعد التأكد من أن جداول الإصدارات السابقة موجودة.
3. لإشعارات Push الحقيقية أضف `google-services.json` الخاص بمشروع Firebase.
4. لا تضع service_role أو Firebase service-account داخل تطبيق Android.
5. راجع `supabase/functions/notify-hashtag-followers/index.ts` واربطه
   بأسرار الخادم قبل تفعيل الإرسال الحقيقي.

## ملاحظة
هذه حزمة تطويرية نهائية وليست نسخة منشورة على Google Play. النشر الفعلي يحتاج
اختبار Build على جهاز، ضبط Firebase/Supabase، Storage policies، ومراجعة
أمان RLS قبل الإنتاج.
