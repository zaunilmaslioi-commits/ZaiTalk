const {onRequest, onCall} = require("firebase-functions/v2/https");
const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();

/*
 * Secure callable endpoint for application/server code.
 * The Android client must NOT contain Firebase Admin credentials.
 */
exports.sendZaiTalkPush = onRequest(async (req, res) => {
  try {
    if (req.method !== "POST") return res.status(405).json({error:"POST required"});

    const {token, title, body, type, reference_id} = req.body || {};
    if (!token || !body) return res.status(400).json({error:"token and body are required"});

    const id = await admin.messaging().send({
      token,
      notification:{title:title || "ZaiTalk", body},
      data:{
        type:String(type || "notification"),
        reference_id:String(reference_id || "")
      },
      android:{
        priority:"high",
        notification:{channelId:"zaitalk_notifications"}
      }
    });

    res.json({ok:true,messageId:id});
  } catch(e) {
    console.error(e);
    res.status(500).json({error:"push_failed"});
  }
});

/*
 * Generic secure helper for trusted backend callers.
 * In production, call this only from authenticated server-side code.
 */
exports.pushToToken = onCall(async (request) => {
  if (!request.auth) throw new Error("authentication required");

  const {token, title, body, type, reference_id} = request.data || {};
  if (!token || !body) throw new Error("token and body are required");

  const id = await admin.messaging().send({
    token,
    notification:{title:title || "ZaiTalk", body},
    data:{
      type:String(type || "notification"),
      reference_id:String(reference_id || "")
    },
    android:{
      priority:"high",
      notification:{channelId:"zaitalk_notifications"}
    }
  });

  return {ok:true,messageId:id};
});
