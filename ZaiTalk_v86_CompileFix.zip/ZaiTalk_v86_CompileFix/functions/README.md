# ZaiTalk Push Server

هذا الجزء مسؤول عن إرسال Push Notifications عبر Firebase Admin SDK.

الإعداد:
1. ثبّت Firebase CLI.
2. داخل مجلد functions شغّل `npm install`.
3. اربط المشروع بمشروع Firebase.
4. انشر Cloud Function.
5. لا تضع Service Account JSON داخل تطبيق Android ولا داخل Git.

Endpoint:
POST /sendZaiTalkPush

Body:
{
  "token": "FCM_DEVICE_TOKEN",
  "title": "ZaiTalk",
  "body": "لديك رسالة جديدة",
  "type": "message",
  "reference_id": "MESSAGE_ID"
}

ملاحظة أمنية:
في الإنتاج يجب حماية endpoint بمصادقة server-to-server أو استدعائه من Trigger موثوق، وعدم تركه مفتوحاً لأي شخص.
