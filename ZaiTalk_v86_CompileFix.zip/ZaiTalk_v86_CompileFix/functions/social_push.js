const admin = require("firebase-admin");
if (!admin.apps.length) admin.initializeApp();

async function sendPush(token, title, body, type, referenceId) {
  return admin.messaging().send({
    token,
    notification: {title, body},
    data: {
      type: String(type || "notification"),
      reference_id: String(referenceId || "")
    },
    android: {
      priority: "high",
      notification: {channelId: "zaitalk_notifications"}
    }
  });
}

exports.sendSocialPush = async function(payload) {
  const {token, title, body, type, reference_id} = payload || {};
  if (!token || !body) throw new Error("token and body are required");
  return sendPush(token, title || "ZaiTalk", body, type, reference_id);
};
