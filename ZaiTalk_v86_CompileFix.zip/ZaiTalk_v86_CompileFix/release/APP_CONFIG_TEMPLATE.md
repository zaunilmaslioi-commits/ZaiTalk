# ZaiTalk Release Configuration

Do not commit secrets.

## local.properties
Use the existing project template and provide:
- SUPABASE_URL
- SUPABASE_KEY

## Firebase
Place the real `google-services.json` in the Android app module when using Firebase Cloud Messaging.

## Release signing
Keep:
- keystore
- passwords
- aliases

outside Git/source archives. Prefer CI secret storage.
