# ZaiTalk v65 — Production Release Checklist

## Android
- [ ] Set applicationId/package and app name.
- [ ] Set versionCode/versionName.
- [ ] Add launcher icon and adaptive icon.
- [ ] Add Firebase `google-services.json` for the real Firebase project.
- [ ] Configure release signing key outside source control.
- [ ] Build a release APK/AAB on a local Android/Gradle environment.
- [ ] Test login, signup, reset password and email confirmation.
- [ ] Test Home, Explore, Reels and Profile.
- [ ] Test Chat text/image/video/voice.
- [ ] Test notifications, realtime and push.
- [ ] Test private accounts, follow requests and blocking.
- [ ] Test reports/admin/verification.
- [ ] Test Storage policies and upload limits.

## Supabase
- [ ] Run the SQL migrations in order.
- [ ] Verify RLS on every user-owned table.
- [ ] Configure Storage buckets and policies.
- [ ] Configure Realtime publications.
- [ ] Configure Edge Functions.
- [ ] Put service-role/Firebase server credentials only in server secrets.
- [ ] Add rate limits/abuse protection before public launch.
- [ ] Add database backups and monitoring.

## Google Play
- [ ] Prepare signed AAB.
- [ ] Add privacy policy URL.
- [ ] Complete Data Safety form.
- [ ] Complete content rating.
- [ ] Prepare screenshots and store listing.
- [ ] Test closed/internal release before production.
