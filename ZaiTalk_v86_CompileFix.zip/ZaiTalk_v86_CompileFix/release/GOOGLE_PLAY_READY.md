# Google Play readiness

Before uploading ZaiTalk:

1. Create a unique application ID if needed.
2. Configure release signing securely.
3. Build an Android App Bundle (`.aab`).
4. Test the signed build on a physical Android phone.
5. Add the production Firebase configuration.
6. Verify Supabase URL/key configuration.
7. Verify every Storage bucket has correct RLS.
8. Verify authentication email/deep-link settings.
9. Verify notification permissions and push delivery.
10. Prepare:
   - app icon
   - screenshots
   - short description
   - full description
   - privacy policy
   - Data Safety answers
   - content rating
11. Upload to an internal/closed test first.
12. Fix crashes and policy issues before production rollout.

Never upload:
- Supabase service_role key
- Firebase service-account private key
- signing keystore/passwords
- other backend secrets
