# Final Test Matrix

| Area | Test |
|---|---|
| Auth | Signup / Login / Logout |
| Recovery | Email confirmation / Reset password |
| Feed | Create / Like / Comment / Save / Share |
| Media | Image / Video upload and playback |
| Reels | Scroll / Playback / Interaction |
| Chat | Text / Image / Video / Voice |
| Presence | Online / Last seen / Read receipts |
| Privacy | Private account / Privacy controls |
| Safety | Block / Report |
| Follow | Follow / Requests / Accept / Reject |
| Explore | User search / Post search |
| Hashtags | Search / Follow / Unfollow |
| Trending | Fresh / Likes / Views / Engagement |
| Notifications | In-app / Realtime / Push |
| Admin | Reports / Verification / Moderation |
| Release | Signed APK/AAB / Physical device |
