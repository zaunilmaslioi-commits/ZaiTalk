# ZaiTalk — دليل التسليم النهائي

## 1) فتح المشروع
- فك الضغط.
- افتح مجلد المشروع في Android Studio.
- انتظر Gradle Sync.
- استخدم JDK/Android SDK المتوافق مع إعدادات المشروع.

## 2) Supabase
- ضع رابط المشروع ومفتاح الـpublishable/anon في إعدادات التطبيق المحلية.
- شغّل SQL الخاص بالجداول والسياسات بالترتيب.
- أنشئ Storage buckets المطلوبة للصور والفيديو والصوت.
- راجع Storage RLS.
- فعّل Realtime للجداول المطلوبة.

## 3) Firebase
- أنشئ مشروع Firebase خاص بك.
- أضف تطبيق Android بنفس package name.
- نزّل `google-services.json`.
- ضعه داخل app module.
- فعّل Firebase Cloud Messaging.

## 4) Release
- استخدم keystore خاص بك.
- لا تضع keystore أو كلمات مرور التوقيع داخل ZIP أو Git.
- ابنِ Signed AAB.
- ثبّت نسخة الاختبار على جهاز حقيقي.

## 5) Google Play
- Internal Testing أولاً.
- راجع crashes.
- أكمل Privacy Policy وData Safety وContent Rating.
- جهّز الصور والوصف والأيقونة.
- بعد نجاح الاختبار انتقل إلى Closed/Production.

## 6) أسرار ممنوع وضعها داخل التطبيق
- Supabase service_role
- Firebase service-account private key
- Keystore passwords
- أي API secret خاص بالخادم

## الحالة
ZaiTalk v69 = Final Handover Package.
