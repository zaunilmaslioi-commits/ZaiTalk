package com.zaitalk.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class ReelsActivity extends Activity {
  private ListView list;
  private ArrayList<JSONObject> reels=new ArrayList<>();

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    list=new ListView(this);
    list.setBackgroundColor(Color.BLACK);
    list.setDivider(null);
    setContentView(list);
    load();
  }

  private void load(){
    new Thread(()->{
      try{
        String raw=SupabaseClient.select(
          "posts?media_type=eq.video&select=*&order=created_at.desc&limit=30");
        JSONArray a=new JSONArray(raw);
        for(int i=0;i<a.length();i++) reels.add(a.getJSONObject(i));
        runOnUiThread(()->{
          list.setAdapter(new ReelsAdapter(null,thisReels()));
          list.setOnScrollListener(new AbsListView.OnScrollListener(){
            public void onScrollStateChanged(AbsListView v,int state){}
            public void onScroll(AbsListView v,int first,int count,int total){}
          });
        });
      }catch(Exception e){}
    }).start();
  }

  private ReelsAdapter thisReels(){
    return new ReelsAdapterProxy(this,reels);
  }

  static class ReelsAdapterProxy extends BaseAdapter {
    final Activity a; final ArrayList<JSONObject> data;
    ReelsAdapterProxy(Activity x,ArrayList<JSONObject> d){a=x;data=d;}
    public int getCount(){return data.size();}
    public Object getItem(int p){return data.get(p);}
    public long getItemId(int p){return p;}
    public View getView(int p,View c,ViewGroup parent){
      FrameLayout box=new FrameLayout(a);
      box.setBackgroundColor(Color.BLACK);
      VideoView v=new VideoView(a);
      box.addView(v,new FrameLayout.LayoutParams(-1,900));
      String url=data.get(p).optString("media_url","");
      if(!url.isEmpty()) MediaPlayerHelper.playVideo(a,v,url);

      TextView t=new TextView(a);
      t.setText(data.get(p).optString("content",""));
      t.setTextColor(Color.WHITE); t.setTextSize(18);
      t.setPadding(18,18,18,30);
      FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);
      box.addView(t,tp);
      return box;
    }
  }
}